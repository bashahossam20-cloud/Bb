# Security Specification - نضام إدارة الكوادر الإعلامية

## Data Invariants
- A worker must have a name and role.
- Completed and pending tasks must be arrays of strings.
- Timestamps must be valid server timestamps.

## The Dirty Dozen Payloads
1. **Identity Theft**: User A tries to create a worker document with an ID belonging to User B (if I were using user isolation, but here it's a shared app - actually, the user didn't specify authentication yet, but I should probably add simple Google Sign-in to protect the data).
2. **Ghost Field**: Adding `isVerified: true` to a worker document.
3. **Huge Data**: Sending a 1MB string in the name field.
4. **Invalid Type**: Sending a boolean for `name`.
5. **Timestamp Spoofing**: Sending a client-side timestamp for `createdAt`.
6. **Task Injection**: Sending an object instead of a string in the tasks array.
7. **Role Escalation**: Modifying a (hypothetical) `isAdmin` field if I added one.
8. **Orphaned Writes**: Updating a worker that doesn't exist.
9. **PII Leak**: Unauthorized read of worker details if restricted.
10. **Query Scraper**: Listing all workers without being signed in.
11. **Negative Counters**: (Not used here, but relevant if using numeric counters).
12. **Status Skipping**: Modifying `createdAt` during update.

## Test Runner (Mock)
`firestore.rules.test.ts` will cover these.
