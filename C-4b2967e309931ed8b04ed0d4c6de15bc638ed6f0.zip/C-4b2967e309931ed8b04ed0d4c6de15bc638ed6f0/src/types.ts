export interface Task {
  id: string;
  title: string;
  startTime: string; // ISO string
  endTime?: string; // ISO string
  status: 'completed' | 'pending' | 'review';
  createdAt: string;
  createdBy: string;
  confirmedBy?: string;
  confirmedAt?: string;
}

export interface Asset {
  id?: string;
  workerId: string;
  workerName: string;
  type: string;
  specifications?: string;
  receivedAt: string;
  returnedAt: string | null;
  returnCondition?: string;
  receivedBackBy?: string;
  handedOverBy: string;
  status: 'active' | 'returned';
  createdAt?: string;
}

export interface Worker {
  id: string;
  name: string;
  role: string;
  phone: string;
  tasks: Task[];
  createdAt: any;
  updatedAt: any;
}

export interface MediaArchive {
  id?: string;
  type: string; // صور، فيديو، الخ
  specifications: string;
  location: string;
  submittedAt: string;
  workerId: string;
  workerName: string;
  status: 'archived'; // For consistency
  createdAt?: any;
}

export interface AppUser {
  id?: string;
  username: string;
  role: 'admin' | 'worker';
  jobTitle?: string;
  isOnline?: boolean;
  lastSeen?: string;
}
