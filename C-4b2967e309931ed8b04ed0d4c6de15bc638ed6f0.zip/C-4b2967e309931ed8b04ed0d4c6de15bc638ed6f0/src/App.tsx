import React from 'react';
import { AuthStatus } from './components/Auth';
import { Dashboard } from './components/Dashboard';
import { NotificationSystem } from './components/Notifications';
import { auth, db } from './lib/firebase';
import { signInAnonymously, onAuthStateChanged } from 'firebase/auth';
import { collection, query, onSnapshot, orderBy, updateDoc, doc } from 'firebase/firestore';
import { Worker, AppUser } from './types';
import { Newspaper, WifiOff } from 'lucide-react';

export default function App() {
  const [currentUser, setCurrentUser] = React.useState<AppUser | null>(() => {
    const saved = localStorage.getItem('app_user');
    return saved ? JSON.parse(saved) : null;
  });
  const [workers, setWorkers] = React.useState<Worker[]>([]);
  const [isOnline, setIsOnline] = React.useState(navigator.onLine);
  const [authReady, setAuthReady] = React.useState(false);

  React.useEffect(() => {
    // Silently sign in anonymously to satisfy Firestore requirements without Google Account
    const unsubscribeAuth = onAuthStateChanged(auth, (user) => {
      if (!user) {
        signInAnonymously(auth).catch(err => console.error("Anonymous auth error:", err));
      } else {
        setAuthReady(true);
      }
    });

    return () => unsubscribeAuth();
  }, []);

  React.useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const handleLogin = (user: AppUser) => {
    setCurrentUser(user);
    localStorage.setItem('app_user', JSON.stringify(user));
  };

  const handleLogout = async () => {
    if (currentUser?.id) {
      try {
        await updateDoc(doc(db, 'users', currentUser.id), {
          isOnline: false,
          lastSeen: new Date().toISOString()
        });
      } catch (e: any) {
        // If document was deleted, we just proceed with local logout
        if (e.code === 'not-found' || e.message?.includes('No document to update')) {
          console.warn("Presence doc not found, proceeding with logout");
        } else {
          console.error("Presence cleanup error", e);
        }
      }
    }
    setCurrentUser(null);
    localStorage.removeItem('app_user');
  };

  React.useEffect(() => {
    if (!currentUser?.id) return;

    // Heartbeat to keep user 'online'
    const interval = setInterval(async () => {
      if (!currentUser?.id) return;
      try {
        await updateDoc(doc(db, 'users', currentUser.id), {
          lastSeen: new Date().toISOString(),
          isOnline: true
        });
      } catch (e: any) {
        if (e.code === 'not-found' || e.message?.includes('No document to update')) {
          console.warn("User document missing, logging out...");
          handleLogout();
        } else {
          console.error("Heartbeat error", e);
        }
      }
    }, 60000); // Every 1 minute

    return () => clearInterval(interval);
  }, [currentUser]);

  React.useEffect(() => {
    if (!authReady) return;
    
    // We still use Firebase for data, but auth is public or handled via UI logic 
    // for this specific requirement of "no email" auth.
    const q = query(collection(db, 'workers'), orderBy('createdAt', 'desc'));
    const unsubscribeWorkers = onSnapshot(q, (snapshot) => {
      setWorkers(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Worker)));
    }, (error) => {
      // If we're not signed in anonymously or otherwise, this might fail depending on rules
      // For now we'll rely on the UI logic.
      console.warn('Data fetch issue:', error);
    });

    return () => unsubscribeWorkers();
  }, [currentUser]);

  return (
    <div className="min-h-screen bg-gray-50">
      {!isOnline && (
        <div className="fixed inset-0 z-[100] bg-white flex flex-col items-center justify-center p-6 text-center">
          <div className="w-24 h-24 bg-red-50 text-red-500 rounded-full flex items-center justify-center mb-6">
            <WifiOff size={48} />
          </div>
          <h2 className="text-3xl font-black text-gray-900 mb-2">أنت غير متصل بالإنترنت</h2>
          <p className="text-gray-500 max-w-sm mb-6">
            يرجى التحقق من اتصالك بالشبكة للمتابعة. النظام يتطلب اتصالاً نشطاً بالإنترنت للعمل بشكل صحيح.
          </p>
          <button 
            onClick={() => window.location.reload()}
            className="px-8 py-3 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 transition-all shadow-lg"
          >
            إعادة المحاولة
          </button>
        </div>
      )}
      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-40 print:hidden">
        <div className="max-w-6xl mx-auto px-4 sm:px-8 h-20 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="bg-indigo-600 text-white p-2 rounded-xl">
              <Newspaper size={28} />
            </div>
            <div className="hidden sm:block">
              <h1 className="text-xl font-bold leading-tight">الكوادر الإعلامية</h1>
              <p className="text-[10px] text-gray-400 font-medium tracking-widest uppercase">نظام إدارة المحتوى والأداء</p>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            <AuthStatus onLogin={handleLogin} onLogout={handleLogout} currentUser={currentUser} />
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="py-8">
        {!currentUser ? (
          <div className="max-w-2xl mx-auto text-center px-4 py-20">
            <div className="w-24 h-24 bg-indigo-50 text-indigo-500 rounded-full flex items-center justify-center mx-auto mb-8 animate-pulse">
              <Newspaper size={48} />
            </div>
            <h2 className="text-3xl font-bold mb-4">نظام إدارة الكوادر</h2>
            <p className="text-gray-500 mb-8 max-w-md mx-auto">
              يرجى تسجيل الدخول باستخدام اسم المستخدم وكلمة المرور الممنوحة لك للوصول إلى النظام.
            </p>
            <div className="flex justify-center">
              <AuthStatus onLogin={handleLogin} onLogout={handleLogout} currentUser={currentUser} />
            </div>
          </div>
        ) : (
          <Dashboard currentUser={currentUser} />
        )}
      </main>

      {/* Footer */}
      <footer className="py-8 text-center text-gray-400 text-sm print:hidden">
        <p>© {new Date().getFullYear()} نظام إدارة الكوادر الإعلامية - جميع الحقوق محفوظة</p>
      </footer>
    </div>
  );
}

