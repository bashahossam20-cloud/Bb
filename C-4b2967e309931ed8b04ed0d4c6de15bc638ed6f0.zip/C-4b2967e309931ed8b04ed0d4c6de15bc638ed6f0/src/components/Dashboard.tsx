import React from 'react';
import { collection, query, orderBy, onSnapshot, addDoc, serverTimestamp, updateDoc, doc, deleteDoc, getDocs } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { Worker, AppUser } from '../types';
import { Plus, User, Trash2, Edit2, CheckCircle2, Circle, FileText, BarChart3, Users, AlertCircle, ShieldCheck, Send, Maximize2, ChevronDown, ChevronUp, Clock, Package, Home, Settings, Bell, Archive, Database } from 'lucide-react';
import { WorkerForm } from './WorkerForm';
import { StatsSummary } from './StatsSummary';
import { ReportView } from './ReportView';
import { UserManagement } from './UserManagement';
import { WorkerSelfView } from './WorkerSelfView';
import { NotificationsFullView, NotificationSystem } from './Notifications';
import { EquipmentManager } from './EquipmentManager';
import { MediaArchiveManager } from './MediaArchiveManager';
import { motion, AnimatePresence } from 'motion/react';

interface DashboardProps {
  currentUser: AppUser;
}

export const Dashboard: React.FC<DashboardProps> = ({ currentUser }) => {
  const [workers, setWorkers] = React.useState<Worker[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [view, setView] = React.useState<'home' | 'list' | 'stats' | 'reports' | 'users' | 'my-tasks' | 'directory' | 'filtered-tasks' | 'approvals' | 'notifications' | 'assets' | 'media-archive'>('home');
  const [notificationsCount, setNotificationsCount] = React.useState(0);
  const [assetSearch, setAssetSearch] = React.useState('');
  const [taskFilter, setTaskFilter] = React.useState<{
    type: 'completed' | 'overdue' | 'uncompleted' | 'in-progress' | 'review' | 'all-workers';
    label: string;
  } | null>(null);
  const [isFormOpen, setIsFormOpen] = React.useState(false);
  const [editingWorker, setEditingWorker] = React.useState<Worker | null>(null);

  // Auto-fullscreen attempt on first interaction
  React.useEffect(() => {
    const triggerFullscreen = () => {
      if (!document.fullscreenElement) {
        document.documentElement.requestFullscreen().catch(() => {
          // Silent fail (expected if browser blocks it)
        });
      }
      document.removeEventListener('click', triggerFullscreen);
    };

    document.addEventListener('click', triggerFullscreen);
    return () => document.removeEventListener('click', triggerFullscreen);
  }, []);

  React.useEffect(() => {
    const q = query(collection(db, 'workers'), orderBy('createdAt', 'desc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Worker));
      setWorkers(data);
      setLoading(false);
    }, (error) => {
      // In custom auth mode, we might need to adjust firestore rules to either be public 
      // or use a secret token. For this demo, we'll keep it simple.
      console.warn('Snapshot error', error);
    });
    return () => unsubscribe();
  }, []);

  const handleDelete = async (id: string) => {
    if (currentUser.role !== 'admin' && currentUser.role !== 'editor') {
      alert('ليس لديك صلاحية الحذف. المسؤول أو المحرر فقط يمكنه القيام بذلك.');
      return;
    }
    const worker = workers.find(w => w.id === id);
    if (!worker) return;

    if (!confirm(`هل أنت متأكد من حذف العامل ${worker.name}؟ سيؤدي ذلك أيضاً لحذف حساب دخوله للنظام.`)) return;
    
    try {
      // Delete Worker Doc
      await deleteDoc(doc(db, 'workers', id));

      // Sync Delete with User account
      const usersSnapshot = await getDocs(query(collection(db, 'users')));
      const userDoc = usersSnapshot.docs.find(d => 
        d.data().username.trim().toLowerCase() === worker.name.trim().toLowerCase()
      );
      if (userDoc) {
        await deleteDoc(doc(db, 'users', userDoc.id));
      }
      alert('تم حذف العامل والحساب المرتبط به بنجاح');
    } catch (error: any) {
      console.error('Delete error:', error);
      handleFirestoreError(error, OperationType.DELETE, `workers/${id}`);
      alert('حدث خطأ أثناء الحذف: ' + (error.message || 'خطأ غير معروف'));
    }
  };

  const handleEdit = (worker: Worker) => {
    if (currentUser.role === 'worker') return;
    setEditingWorker(worker);
    setIsFormOpen(true);
  };

  const isManagement = currentUser.role === 'admin' || currentUser.role === 'editor';

  return (
    <div className="min-h-screen bg-gray-50 pt-36 pb-10 sm:pt-0 sm:pb-0">
      <main className="max-w-7xl mx-auto p-4 sm:p-8">
        {/* Desktop Sidebar / Horizontal Nav */}
        <div className="hidden sm:flex flex-wrap items-center justify-between gap-4 mb-8">
          <div className="flex items-center gap-1 bg-white p-1 rounded-2xl shadow-sm border border-gray-100">
            <NavButton 
              active={view === 'home'} 
              onClick={() => setView('home')} 
              icon={<Home size={18} />} 
              label="الرئيسية" 
            />
            {isManagement && (
              <>
                <NavButton 
                  active={view === 'list'} 
                  onClick={() => setView('list')} 
                  icon={<Users size={18} />} 
                  label="إدارة الكادر" 
                />
                <NavButton 
                  active={view === 'stats' || view === 'filtered-tasks'} 
                  onClick={() => setView('stats')} 
                  icon={<BarChart3 size={18} />} 
                  label="المهام" 
                />
                <NavButton 
                  active={view === 'approvals'} 
                  onClick={() => setView('approvals')} 
                  icon={<ShieldCheck size={18} className="text-amber-500" />} 
                  label="اعتماد المهام" 
                />
                <NavButton 
                  active={view === 'reports'} 
                  onClick={() => setView('reports')} 
                  icon={<FileText size={18} />} 
                  label="التقارير" 
                />
                <NavButton 
                  active={view === 'media-archive'} 
                  onClick={() => setView('media-archive')} 
                  icon={<Archive size={18} />} 
                  label="الأرشيف" 
                />
              </>
            )}

            {currentUser.role === 'worker' && (
              <>
                <NavButton 
                  active={view === 'my-tasks'} 
                  onClick={() => setView('my-tasks')} 
                  icon={<Circle size={18} />} 
                  label="مهامي" 
                />
                <NavButton 
                  active={view === 'directory'} 
                  onClick={() => setView('directory')} 
                  icon={<Users size={18} />} 
                  label="الدليل" 
                />
                {(currentUser.role === 'admin' || currentUser.role === 'editor') && (
                  <NavButton 
                    active={view === 'assets'} 
                    onClick={() => {
                      setAssetSearch('');
                      setView('assets');
                    }} 
                    icon={<Package size={18} />} 
                    label="العُهد" 
                  />
                )}
              </>
            )}

            {currentUser.role === 'admin' && (
              <NavButton 
                active={view === 'users'} 
                onClick={() => setView('users')} 
                icon={<Settings size={18} />} 
                label="المستخدمين" 
              />
            )}
            
            <div className="h-6 w-[1px] bg-gray-100 mx-1 hidden sm:block"></div>
            <NotificationSystem 
              workers={workers} 
              onViewAll={() => setView('notifications')} 
              onCountChange={setNotificationsCount}
            />
          </div>

          {isManagement && (
            <button
              onClick={() => { setEditingWorker(null); setIsFormOpen(true); }}
              className="flex items-center gap-2 bg-indigo-600 text-white px-6 py-3 rounded-2xl hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100 font-bold text-sm"
            >
              <Plus size={20} />
              <span>إضافة عامل</span>
            </button>
          )}
        </div>

        <AnimatePresence mode="wait">
          {view === 'home' && (
            <motion.div
              key="home"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-8 pb-10"
            >
              {/* Urgent Notifications Alert */}
              {notificationsCount > 0 && (
              <motion.button 
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                onClick={() => setView('notifications')}
                className="col-span-full bg-indigo-600 p-6 rounded-[2.5rem] text-white flex items-center justify-between shadow-xl shadow-indigo-200 border-b-8 border-b-indigo-800 active:scale-95 transition-all mb-4"
              >
                <div className="flex items-center gap-4 text-right">
                  <div className="w-12 h-12 bg-white/20 rounded-2xl flex items-center justify-center">
                    <Bell size={28} />
                  </div>
                  <div>
                    <h3 className="text-xl font-black">مركز التنبيهات النشط</h3>
                    <p className="text-xs font-bold opacity-90">يوجد {notificationsCount} تحديثات جديدة تتطلب انتباهك حالياً.</p>
                  </div>
                </div>
                <div className="flex items-center gap-2 bg-white/20 px-4 py-2 rounded-xl font-black text-sm">
                  <span>فتح التنبيهات</span>
                  <Maximize2 size={16} />
                </div>
              </motion.button>
            )}

            {/* Pending Approvals Alert for Management */}
            {isManagement && workers.some(w => (w.tasks || []).some(t => t.status === 'review')) && (
              <motion.button 
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                onClick={() => setView('approvals')}
                className="col-span-full bg-amber-500 p-6 rounded-[2.5rem] text-white flex items-center justify-between shadow-xl shadow-amber-200 border-b-8 border-b-amber-700 active:scale-95 transition-all mb-4"
              >
                <div className="flex items-center gap-4 text-right">
                  <div className="w-12 h-12 bg-white/20 rounded-2xl flex items-center justify-center">
                    <ShieldCheck size={28} />
                  </div>
                  <div>
                    <h3 className="text-xl font-black">طلبات الاعتماد</h3>
                    <p className="text-xs font-bold opacity-90">هناك مهام جديدة تم إنجازها وبانتظار اعتمادك الإداري.</p>
                  </div>
                </div>
                <div className="flex items-center gap-2 bg-white/20 px-4 py-2 rounded-xl font-black text-sm">
                  <span>مراجعة الآن</span>
                  <Maximize2 size={16} />
                </div>
              </motion.button>
            )}

            {/* Main Navigation Portals */}
            <div className="col-span-full grid grid-cols-1 md:grid-cols-3 gap-4 sm:gap-6">
              {/* Staff Directory Portal */}
              <button 
                onClick={() => setView(currentUser.role === 'worker' ? 'directory' : 'list')}
                className="group relative overflow-hidden bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-sm hover:shadow-2xl transition-all text-right flex flex-col items-start gap-4 border-b-8 border-b-indigo-600"
              >
                <div className="w-16 h-16 bg-indigo-50 text-indigo-600 rounded-3xl flex items-center justify-center group-hover:scale-110 group-hover:rotate-6 transition-all">
                  <Users size={32} />
                </div>
                <div>
                  <h3 className="text-2xl font-black text-gray-900 mb-1">دليل الكادر</h3>
                  <p className="text-gray-500 text-sm leading-relaxed">استكشف الفريق الإعلامي، تواصل مع الزملاء وشاهد الملفات.</p>
                </div>
                <div className="mt-auto flex items-center gap-2 text-indigo-600 font-bold text-xs">
                  <span>دخول الآن</span>
                  <Maximize2 size={12} />
                </div>
              </button>

              {/* Tasks Portal */}
              <button 
                onClick={() => setView(currentUser.role === 'worker' ? 'my-tasks' : 'stats')}
                className="group relative overflow-hidden bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-sm hover:shadow-2xl transition-all text-right flex flex-col items-start gap-4 border-b-8 border-b-emerald-600"
              >
                <div className="w-16 h-16 bg-emerald-50 text-emerald-600 rounded-3xl flex items-center justify-center group-hover:scale-110 group-hover:-rotate-6 transition-all">
                  <BarChart3 size={32} />
                </div>
                <div>
                  <h3 className="text-2xl font-black text-gray-900 mb-1">إدارة المهام</h3>
                  <p className="text-gray-500 text-sm leading-relaxed">
                    {currentUser.role === 'worker' ? 'تابع مهامك اليومية ومواعيد العمل بوضوح.' : 'إدارة سير العمل، مراقبة الإنجاز وإصدار التقارير.'}
                  </p>
                </div>
                <div className="mt-auto flex items-center gap-2 text-emerald-600 font-bold text-xs">
                  <span>دخول الآن</span>
                  <Maximize2 size={12} />
                </div>
              </button>

              {/* Assets Management Portal or Reports */}
              {isManagement ? (
                <button 
                  onClick={() => setView('media-archive')}
                  className="group relative overflow-hidden bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-sm hover:shadow-2xl transition-all text-right flex flex-col items-start gap-4 border-b-8 border-b-rose-600"
                >
                  <div className="w-16 h-16 bg-rose-50 text-rose-600 rounded-3xl flex items-center justify-center group-hover:scale-110 group-hover:rotate-6 transition-all">
                    <Archive size={32} />
                  </div>
                  <div>
                    <h3 className="text-2xl font-black text-gray-900 mb-1">الأرشيف</h3>
                    <p className="text-gray-500 text-sm leading-relaxed">أرشيف المواد الإعلامية (صور، فيديو) وتوثيق استلامها من الكادر.</p>
                  </div>
                  <div className="mt-auto flex items-center gap-2 text-rose-600 font-bold text-xs">
                    <span>دخول الآن</span>
                    <Maximize2 size={12} />
                  </div>
                </button>
              ) : (
                <div className="bg-gradient-to-br from-indigo-500 to-indigo-700 p-8 rounded-[2.5rem] text-white flex flex-col items-start gap-4">
                  <div className="w-16 h-16 bg-white/20 rounded-3xl flex items-center justify-center">
                    <User size={32} />
                  </div>
                  <div>
                    <h3 className="text-2xl font-black mb-1">حسابك الشخصي</h3>
                    <p className="text-white/80 text-sm leading-relaxed">أهلاً بك {currentUser.username}، نتمنى لك يوماً سعيداً ومليئاً بالإنجاز.</p>
                  </div>
                </div>
              )}
            </div>

            {/* Assets Management Quick Link */}
            {(currentUser.role === 'admin' || currentUser.role === 'editor') && (
              <div className="col-span-full grid grid-cols-1 md:grid-cols-2 gap-4">
                <button 
                  onClick={() => {
                    setAssetSearch('');
                    setView('assets');
                  }}
                  className="group relative overflow-hidden bg-white p-6 rounded-[2rem] border border-gray-100 shadow-sm hover:shadow-lg transition-all text-right flex items-center gap-6 border-b-4 border-b-amber-500"
                >
                  <div className="w-12 h-12 bg-amber-50 text-amber-600 rounded-2xl flex items-center justify-center group-hover:scale-110 transition-all">
                    <Package size={28} />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-xl font-black text-gray-900">العُهد</h3>
                    <p className="text-gray-500 text-xs mt-1">تتبع المعدات المسلمة واستلام العُهد من الكادر الإعلامي.</p>
                  </div>
                  <div className="flex items-center gap-2 text-amber-600 font-bold text-xs px-4 py-2 bg-amber-50 rounded-xl">
                    <span>المستودع</span>
                    <Maximize2 size={12} />
                  </div>
                </button>

                <button 
                  onClick={() => setView('reports')}
                  className="group relative overflow-hidden bg-white p-6 rounded-[2rem] border border-gray-100 shadow-sm hover:shadow-lg transition-all text-right flex items-center gap-6 border-b-4 border-b-indigo-500"
                >
                  <div className="w-12 h-12 bg-indigo-50 text-indigo-600 rounded-2xl flex items-center justify-center group-hover:scale-110 transition-all">
                    <FileText size={28} />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-xl font-black text-gray-900">التقارير</h3>
                    <p className="text-gray-500 text-xs mt-1">تحليل أداء الكادر وإصدار إحصائيات العمل.</p>
                  </div>
                  <div className="flex items-center gap-2 text-indigo-600 font-bold text-xs px-4 py-2 bg-indigo-50 rounded-xl">
                    <span>عرض التقارير</span>
                    <Maximize2 size={12} />
                  </div>
                </button>
              </div>
            )}
          </motion.div>
        )}

        {view === 'list' && isManagement && (
          <motion.div
            key="list"
            initial={{ opacity: 0, scale: 0.98 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.98 }}
            className="space-y-6"
          >
            <div className="flex flex-wrap items-center justify-between gap-4 bg-white p-4 rounded-3xl border border-gray-100 shadow-sm">
              <div className="flex items-center gap-4">
                <button 
                  onClick={() => setView('home')} 
                  className="flex items-center gap-2 px-3 py-2 bg-gray-50 hover:bg-gray-100 rounded-xl transition-all text-gray-700 font-bold text-sm border border-gray-100 shadow-sm"
                >
                  <Send size={16} className="rotate-180" />
                  <span>رجوع</span>
                </button>
                <h2 className="text-xl font-black text-gray-900">دليل الكادر الإعلامي</h2>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {loading ? (
                <div className="col-span-full py-20 text-center text-gray-400">جاري التحميل...</div>
              ) : workers.length === 0 ? (
                <div className="col-span-full py-20 text-center bg-white rounded-3xl border-2 border-dashed border-gray-200 text-gray-400">
                  لا يوجد عاملين حالياً. قم بإضافة أول عامل للبدء.
                </div>
              ) : (
                workers.map(worker => (
                  <WorkerCard 
                    key={worker.id} 
                    worker={worker} 
                    onDelete={() => handleDelete(worker.id)}
                    onEdit={() => handleEdit(worker)}
                    onViewAssets={() => {
                      setAssetSearch(worker.name);
                      setView('assets');
                    }}
                    isAdmin={currentUser.role === 'admin'}
                    currentUser={currentUser}
                  />
                ))
              )}
            </div>
          </motion.div>
        )}

        {view === 'stats' && isManagement && (
          <motion.div
            key="stats"
            initial={{ opacity: 0, scale: 0.98 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.98 }}
            className="space-y-6"
          >
            <div className="flex items-center gap-4 bg-white p-4 rounded-3xl border border-gray-100 shadow-sm">
              <button 
                onClick={() => setView('home')} 
                className="flex items-center gap-2 px-3 py-2 bg-gray-50 hover:bg-gray-100 rounded-xl transition-all text-gray-700 font-bold text-sm border border-gray-100 shadow-sm"
              >
                <Send size={16} className="rotate-180" />
                <span>رجوع</span>
              </button>
              <h2 className="text-xl font-black text-gray-900">إدارة المهام</h2>
            </div>
            <StatsSummary 
              workers={workers} 
              onFilterClick={(type, label) => {
                if (type === 'all-workers') {
                  setView('list');
                } else {
                  setTaskFilter({ type, label });
                  setView('filtered-tasks');
                }
              }} 
            />
          </motion.div>
        )}

        {view === 'filtered-tasks' && isManagement && taskFilter && (
          <FilteredTaskView 
            workers={workers} 
            filter={taskFilter.type} 
            label={taskFilter.label}
            onBack={() => setView('stats')}
            currentUser={currentUser}
          />
        )}
        {view === 'approvals' && isManagement && (
          <FilteredTaskView 
            workers={workers} 
            filter="review" 
            label="مهام بانتظار الاعتماد"
            onBack={() => setView('home')}
            currentUser={currentUser}
          />
        )}
        {view === 'reports' && isManagement && (
          <motion.div
            key="reports"
            initial={{ opacity: 0, scale: 0.98 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.98 }}
            className="space-y-6"
          >
            <div className="flex items-center gap-4 bg-white p-4 rounded-3xl border border-gray-100 shadow-sm">
              <button 
                onClick={() => setView('home')} 
                className="flex items-center gap-2 px-3 py-2 bg-gray-50 hover:bg-gray-100 rounded-xl transition-all text-gray-700 font-bold text-sm border border-gray-100 shadow-sm"
              >
                <Send size={16} className="rotate-180" />
                <span>رجوع</span>
              </button>
              <h2 className="text-xl font-black text-gray-900">التقارير التحليلية</h2>
            </div>
            <ReportView workers={workers} />
          </motion.div>
        )}
        {view === 'users' && currentUser.role === 'admin' && (
          <motion.div
            key="users"
            initial={{ opacity: 0, scale: 0.98 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.98 }}
            className="space-y-6"
          >
            <div className="flex items-center gap-4 bg-white p-4 rounded-3xl border border-gray-100 shadow-sm">
              <button 
                onClick={() => setView('home')} 
                className="flex items-center gap-2 px-3 py-2 bg-gray-50 hover:bg-gray-100 rounded-xl transition-all text-gray-700 font-bold text-sm border border-gray-100 shadow-sm"
              >
                <Send size={16} className="rotate-180" />
                <span>رجوع</span>
              </button>
              <h2 className="text-xl font-black text-gray-900">إدارة المستخدمين</h2>
            </div>
            <UserManagement />
          </motion.div>
        )}
        {view === 'my-tasks' && (
          <motion.div
            key="my-tasks"
            initial={{ opacity: 0, scale: 0.98 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.98 }}
            className="space-y-6"
          >
            <div className="flex items-center gap-4 bg-white p-4 rounded-3xl border border-gray-100 shadow-sm">
              <button 
                onClick={() => setView('home')} 
                className="flex items-center gap-2 px-3 py-2 bg-gray-50 hover:bg-gray-100 rounded-xl transition-all text-gray-700 font-bold text-sm border border-gray-100 shadow-sm"
              >
                <Send size={16} className="rotate-180" />
                <span>رجوع</span>
              </button>
              <h2 className="text-xl font-black text-gray-900">مهامي الشخصية</h2>
            </div>
            <WorkerSelfView workers={workers} currentUser={currentUser} />
          </motion.div>
        )}
        
        {view === 'notifications' && (
          <motion.div
            key="notifications"
            initial={{ opacity: 0, scale: 0.98 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.98 }}
            className="space-y-6"
          >
            <div className="flex items-center gap-4 bg-white p-4 rounded-3xl border border-gray-100 shadow-sm">
              <button 
                onClick={() => setView('home')} 
                className="flex items-center gap-2 px-3 py-2 bg-gray-50 hover:bg-gray-100 rounded-xl transition-all text-gray-700 font-bold text-sm border border-gray-100 shadow-sm"
              >
                <Send size={16} className="rotate-180" />
                <span>رجوع</span>
              </button>
              <h2 className="text-xl font-black text-gray-900">مركز التنبيهات</h2>
            </div>
            <NotificationsFullView workers={workers} />
          </motion.div>
        )}

        {view === 'assets' && isManagement && (
          <motion.div
            key="assets"
            initial={{ opacity: 0, scale: 0.98 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.98 }}
            className="space-y-6"
          >
            <div className="flex items-center gap-4 bg-white p-4 rounded-3xl border border-gray-100 shadow-sm">
              <button 
                onClick={() => setView('home')} 
                className="flex items-center gap-2 px-3 py-2 bg-gray-50 hover:bg-gray-100 rounded-xl transition-all text-gray-700 font-bold text-sm border border-gray-100 shadow-sm"
              >
                <Send size={16} className="rotate-180" />
                <span>رجوع</span>
              </button>
              <h2 className="text-xl font-black text-gray-900">إدارة العُهد والمعدات</h2>
            </div>
            <EquipmentManager workers={workers} initialSearch={assetSearch} currentUser={currentUser} />
          </motion.div>
        )}

        {view === 'media-archive' && isManagement && (
          <motion.div
            key="media-archive"
            initial={{ opacity: 0, scale: 0.98 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.98 }}
            className="space-y-6"
          >
            <div className="flex items-center gap-4 bg-white p-4 rounded-3xl border border-gray-100 shadow-sm">
              <button 
                onClick={() => setView('home')} 
                className="flex items-center gap-2 px-3 py-2 bg-gray-50 hover:bg-gray-100 rounded-xl transition-all text-gray-700 font-bold text-sm border border-gray-100 shadow-sm"
              >
                <Send size={16} className="rotate-180" />
                <span>رجوع</span>
              </button>
              <h2 className="text-xl font-black text-gray-900">أرشيف المواد الإعلامية</h2>
            </div>
            <MediaArchiveManager workers={workers} currentUser={currentUser} />
          </motion.div>
        )}
        
        {view === 'directory' && (
          <motion.div
            key="directory"
            initial={{ opacity: 0, scale: 0.98 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.98 }}
            className="space-y-6"
          >
            <div className="flex items-center gap-4 bg-white p-4 rounded-3xl border border-gray-100 shadow-sm mb-6">
              <button 
                onClick={() => setView('home')} 
                className="flex items-center gap-2 px-3 py-2 bg-gray-50 hover:bg-gray-100 rounded-xl transition-all text-gray-700 font-bold text-sm border border-gray-100 shadow-sm"
              >
                <Send size={16} className="rotate-180" />
                <span>رجوع</span>
              </button>
              <h2 className="text-xl font-black text-gray-900">دليل الفريق الإعلامي</h2>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {workers.map(worker => (
                <WorkerCard 
                  key={worker.id} 
                  worker={worker} 
                  onDelete={() => {}}
                  onEdit={() => {}}
                  onViewAssets={() => {
                    setAssetSearch(worker.name);
                    setView('assets');
                  }}
                  isAdmin={false}
                  readOnly={true}
                  currentUser={currentUser}
                />
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      </main>

      {/* Mobile Top Navigation */}
      <nav className="sm:hidden fixed top-20 left-0 right-0 bg-white border-b border-gray-100 px-4 py-2 flex justify-between items-center z-50 shadow-[0_4px_12px_rgba(0,0,0,0.05)] overflow-x-auto no-scrollbar whitespace-nowrap gap-4">
        <MobileNavButton 
          active={view === 'home'} 
          onClick={() => setView('home')} 
          icon={<Home size={20} />} 
          label="الرئيسية" 
        />
        {isManagement ? (
          <>
            <MobileNavButton 
              active={view === 'list'} 
              onClick={() => setView('list')} 
              icon={<Users size={20} />} 
              label="إدارة الكوادر" 
            />
            <MobileNavButton 
              active={view === 'stats' || view === 'filtered-tasks'} 
              onClick={() => setView('stats')} 
              icon={<BarChart3 size={20} />} 
              label="المهام" 
            />
            <MobileNavButton 
              active={view === 'approvals'} 
              onClick={() => setView('approvals')} 
              icon={<ShieldCheck size={20} className="text-amber-500" />} 
              label="اعتماد" 
            />
            <MobileNavButton 
              active={view === 'reports'} 
              onClick={() => setView('reports')} 
              icon={<FileText size={20} />} 
              label="التقارير" 
            />
            <MobileNavButton 
              active={view === 'assets'} 
              onClick={() => {
                setAssetSearch('');
                setView('assets');
              }} 
              icon={<Package size={20} />} 
              label="العُهد" 
            />
            <MobileNavButton 
              active={view === 'media-archive'} 
              onClick={() => setView('media-archive')} 
              icon={<Archive size={20} />} 
              label="الأرشيف" 
            />
          </>
        ) : (
          <>
            <MobileNavButton 
              active={view === 'my-tasks'} 
              onClick={() => setView('my-tasks')} 
              icon={<Circle size={20} />} 
              label="مهامي" 
            />
            <MobileNavButton 
              active={view === 'directory'} 
              onClick={() => setView('directory')} 
              icon={<Users size={20} />} 
              label="الفريق" 
            />
          </>
        )}
        {currentUser.role === 'admin' && (
          <MobileNavButton 
            active={view === 'users'} 
            onClick={() => setView('users')} 
            icon={<Settings size={20} />} 
            label="الضبط" 
          />
        )}
      </nav>

      {isManagement && (
        <button
          onClick={() => { setEditingWorker(null); setIsFormOpen(true); }}
          className="sm:hidden fixed bottom-6 left-6 w-14 h-14 bg-indigo-600 text-white rounded-2xl shadow-xl shadow-indigo-200 flex items-center justify-center active:scale-90 transition-all z-40"
        >
          <Plus size={28} />
        </button>
      )}

      {isManagement && (
        <WorkerForm 
          isOpen={isFormOpen} 
          onClose={() => setIsFormOpen(false)} 
          initialData={editingWorker} 
          currentUser={currentUser}
          existingWorkers={workers}
        />
      )}
    </div>
  );
};

const MobileNavButton: React.FC<{ active: boolean; onClick: () => void; icon: React.ReactNode; label: string }> = ({ active, onClick, icon, label }) => (
  <button
    onClick={onClick}
    className={`flex flex-col items-center gap-1 transition-all ${
      active ? 'text-indigo-600 font-bold' : 'text-gray-400'
    }`}
  >
    <div className={`p-1 rounded-lg transition-all ${active ? 'bg-indigo-50' : ''}`}>
      {icon}
    </div>
    <span className="text-[9px] uppercase tracking-tighter">{label}</span>
  </button>
);

const FilteredTaskView: React.FC<{ 
  workers: Worker[]; 
  filter: 'completed' | 'overdue' | 'uncompleted' | 'in-progress' | 'review'; 
  label: string;
  onBack: () => void;
  currentUser: AppUser;
}> = ({ workers, filter, label, onBack, currentUser }) => {
  const now = new Date();
  
  const allTasks = React.useMemo(() => {
    const tasks: { task: any; worker: Worker }[] = [];
    workers.forEach(w => {
      (w.tasks || []).forEach(t => {
        const startTime = new Date(t.startTime).getTime();
        const diffHours = (now.getTime() - startTime) / (1000 * 60 * 60);
        
        let currentStatus: 'completed' | 'overdue' | 'uncompleted' | 'in-progress' | 'review' = 'in-progress';
        if (t.status === 'review') currentStatus = 'review';
        else if (t.status === 'completed') currentStatus = 'completed';
        else if (diffHours >= 24) currentStatus = 'uncompleted';
        else if (diffHours >= 5) currentStatus = 'overdue';
        else currentStatus = 'in-progress';
        
        if (filter === currentStatus) {
          tasks.push({ task: t, worker: w });
        }
      });
    });

    // Sorting
    if (filter === 'overdue') {
      // Oldest to newest (based on startTime)
      return tasks.sort((a, b) => new Date(a.task.startTime).getTime() - new Date(b.task.startTime).getTime());
    } else {
      // Newest to oldest (based on createdAt)
      return tasks.sort((a, b) => new Date(b.task.createdAt).getTime() - new Date(a.task.createdAt).getTime());
    }
  }, [workers, filter]);

  return (
    <motion.div
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      className="space-y-6"
    >
      <div className="flex flex-wrap items-center justify-between gap-4 bg-white p-4 rounded-3xl border border-gray-100 shadow-sm">
        <div className="flex items-center gap-4">
          <button onClick={onBack} className="flex items-center gap-2 px-3 py-2 bg-gray-50 hover:bg-gray-100 rounded-xl transition-all text-gray-700 font-bold text-sm border border-gray-100 shadow-sm">
            <Send size={16} className="rotate-180" />
            <span>رجوع</span>
          </button>
          <div>
            <h2 className="text-xl font-black text-gray-900">{label}</h2>
            <p className="text-xs text-gray-400">عدد المهام: {allTasks.length}</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {allTasks.length === 0 ? (
          <div className="col-span-full py-20 text-center bg-white rounded-3xl border border-dashed border-gray-200 text-gray-400">
            لا توجد مهام في هذا التصنيف حالياً.
          </div>
        ) : (
          allTasks.map(({ task, worker }, idx) => {
            const startTime = new Date(task.startTime).getTime();
            const diffHours = (now.getTime() - startTime) / (1000 * 60 * 60);
            const isUncompleted = task.status !== 'completed' && diffHours >= 24;
            const isOverdue = task.status !== 'completed' && diffHours >= 5 && diffHours < 24;
            const isReview = task.status === 'review';
            const isManagement = currentUser.role === 'admin' || currentUser.role === 'editor';

            const handleApprove = async () => {
              if (!isManagement) return;
              try {
                const updatedTasks = worker.tasks.map(t => 
                  t.id === task.id ? { 
                    ...t, 
                    status: 'completed' as const,
                    confirmedBy: currentUser.username,
                    confirmedAt: new Date().toISOString()
                  } : t
                );
                await updateDoc(doc(db, 'workers', worker.id), {
                  tasks: updatedTasks,
                  updatedAt: serverTimestamp()
                });
                alert('تم اعتماد المهمة بنجاح');
              } catch (error) {
                console.error('Error approving task:', error);
                alert('فشل اعتماد المهمة');
              }
            };

            const handleReject = async () => {
              if (!isManagement) return;
              if (!confirm('هل تريد فعلاً رفض هذه المهمة وإعادتها للعامل؟')) return;
              try {
                const updatedTasks = worker.tasks.map(t => 
                  t.id === task.id ? { 
                    ...t, 
                    status: 'pending' as const,
                    rejectionNote: 'طلب مراجعة من الإدارة'
                  } : t
                );
                await updateDoc(doc(db, 'workers', worker.id), {
                  tasks: updatedTasks,
                  updatedAt: serverTimestamp()
                });
                alert('تم رفض المهمة وإعادتها للعامل للتنفيذ');
              } catch (error) {
                console.error('Error rejecting task:', error);
                alert('فشل رفض المهمة');
              }
            };
            
            return (
              <motion.div 
                key={`${task.id}-${idx}`}
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: idx * 0.05 }}
                className="bg-white p-5 rounded-[2.5rem] border border-gray-100 shadow-sm relative overflow-hidden flex flex-col group transition-all hover:shadow-lg"
              >
                <div className={`absolute top-0 right-0 w-2 h-full ${
                  isReview ? 'bg-amber-500' :
                  task.status === 'completed' ? 'bg-green-500' :
                  isUncompleted ? 'bg-orange-500' :
                  isOverdue ? 'bg-red-500' : 'bg-indigo-500'
                }`} />
                
                <div className="flex justify-between items-start mb-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-2xl bg-indigo-50 flex items-center justify-center text-indigo-600">
                      <User size={20} />
                    </div>
                    <div>
                      <p className="text-sm font-black text-gray-900">{worker.name}</p>
                      <p className="text-[10px] text-gray-400 font-medium">{worker.role}</p>
                    </div>
                  </div>
                  <span className={`text-[8px] px-2 py-1 rounded-lg font-black uppercase shadow-sm ${
                    isReview ? 'bg-amber-100 text-amber-700' :
                    task.status === 'completed' ? 'bg-green-100 text-green-700' :
                    isUncompleted ? 'bg-orange-100 text-orange-700' :
                    isOverdue ? 'bg-red-100 text-red-700' : 'bg-indigo-100 text-indigo-700'
                  }`}>
                    {isReview ? 'مراجعة' :
                     task.status === 'completed' ? 'معتمد' : 
                     isUncompleted ? 'غير منجز' : 
                     isOverdue ? 'متأخر' : 'نشط'}
                  </span>
                </div>

                <h4 className={`text-sm font-bold leading-relaxed mb-4 flex-1 ${task.status === 'completed' ? 'text-gray-400 line-through' : 'text-gray-800'}`}>
                  {task.title}
                </h4>

                {task.confirmedBy && (
                  <div className="flex items-center gap-1 mb-4 text-[9px] text-emerald-600 font-bold bg-emerald-50 p-1.5 rounded-lg border border-emerald-100">
                    <ShieldCheck size={12} />
                    <span>تم الاعتماد بواسطة: {task.confirmedBy}</span>
                  </div>
                )}

                <div className="flex items-center justify-between mt-auto pt-4 border-t border-gray-50">
                  <div className="flex items-center gap-1.5 text-[9px] text-gray-400 font-bold">
                    <Clock size={12} />
                    <span>{new Date(task.startTime).toLocaleString('ar-EG', { hour: 'numeric', minute: 'numeric', day: 'numeric', month: 'numeric' })}</span>
                  </div>
                  {isReview && isManagement && (
                    <div className="flex gap-2">
                       <button 
                        onClick={handleReject}
                        className="bg-rose-100 text-rose-700 px-3 py-1.5 rounded-xl text-[9px] font-black hover:bg-rose-200 transition-all active:scale-95 border border-rose-200"
                      >
                        رفض
                      </button>
                      <button 
                        onClick={handleApprove}
                        className="bg-emerald-600 text-white px-3 py-1.5 rounded-xl text-[9px] font-black hover:bg-emerald-700 transition-all shadow-md active:scale-95"
                      >
                        اعتماد
                      </button>
                    </div>
                  )}
                </div>
              </motion.div>
            );
          })
        )}
      </div>
    </motion.div>
  );
};

const NavButton: React.FC<{ active: boolean; onClick: () => void; icon: React.ReactNode; label: string }> = ({ active, onClick, icon, label }) => (
  <button
    onClick={onClick}
    className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-all ${
      active ? 'bg-indigo-50 text-indigo-700' : 'text-gray-500 hover:bg-gray-50'
    }`}
  >
    {icon}
    <span className="font-medium">{label}</span>
  </button>
);

const WorkerCard: React.FC<{ 
  worker: Worker; 
  onDelete: () => void; 
  onEdit: () => void;
  onViewAssets?: () => void;
  isAdmin: boolean;
  currentUser: AppUser;
  readOnly?: boolean;
}> = ({ worker, onDelete, onEdit, onViewAssets, isAdmin, currentUser, readOnly }) => {
  const [showTasks, setShowTasks] = React.useState(false);
  const now = new Date();
  const tasks = worker.tasks || [];
  
  const getTaskDetailedStatus = (task: any) => {
    if (task.status === 'completed') return 'completed';
    const startTime = new Date(task.startTime).getTime();
    const diffHours = (now.getTime() - startTime) / (1000 * 60 * 60);
    
    if (diffHours >= 24) return 'uncompleted';
    if (diffHours >= 5) return 'overdue';
    return 'in-progress';
  };

  const completed = tasks.filter(t => getTaskDetailedStatus(t) === 'completed');
  const uncompleted = tasks.filter(t => getTaskDetailedStatus(t) === 'uncompleted');
  const overdue = tasks.filter(t => getTaskDetailedStatus(t) === 'overdue');
  const inProgress = tasks.filter(t => getTaskDetailedStatus(t) === 'in-progress');

  const canSeeTasks = currentUser.role !== 'worker' || currentUser.username === worker.name;
  const isManagement = currentUser.role === 'admin' || currentUser.role === 'editor';
  
  const handleApproveTask = async (taskId: string) => {
    if (!isManagement) return;
    try {
      const updatedTasks = worker.tasks.map(t => 
        t.id === taskId ? { 
          ...t, 
          status: 'completed' as const,
          confirmedBy: currentUser.username,
          confirmedAt: new Date().toISOString()
        } : t
      );
      await updateDoc(doc(db, 'workers', worker.id), {
        tasks: updatedTasks,
        updatedAt: serverTimestamp()
      });
      alert('تم اعتماد المهمة بنجاح');
    } catch (error) {
      console.error('Error approving task:', error);
      alert('فشل اعتماد المهمة');
    }
  };

  const handleRejectTask = async (taskId: string) => {
    if (!isManagement) return;
    if (!confirm('هل تريد فعلاً رفض هذه المهمة وإعادتها للعامل؟')) return;
    try {
      const updatedTasks = worker.tasks.map(t => 
        t.id === taskId ? { 
          ...t, 
          status: 'pending' as const,
          rejectionNote: 'طلب مراجعة من الإدارة'
        } : t
      );
      await updateDoc(doc(db, 'workers', worker.id), {
        tasks: updatedTasks,
        updatedAt: serverTimestamp()
      });
      alert('تم رفض المهمة وإعادتها للعامل للتنفيذ');
    } catch (error) {
      console.error('Error rejecting task:', error);
      alert('فشل رفض المهمة');
    }
  };

  const totalTasks = tasks.length;
  const successRate = totalTasks > 0 ? (completed.length / totalTasks) * 100 : 0;
  const nonCompletionRate = totalTasks > 0 ? ((uncompleted.length + overdue.length + inProgress.length) / totalTasks) * 100 : 0;

  return (
    <div className="bg-white p-6 rounded-3xl shadow-sm border border-gray-100 hover:shadow-md transition-all group overflow-hidden">
      <div className="flex justify-between items-start mb-4">
        <div className="bg-indigo-100 p-3 rounded-2xl text-indigo-600">
          <User size={24} />
        </div>
        {!readOnly && (
          <div className="flex gap-2">
            <button onClick={onEdit} className="p-2 text-gray-400 hover:text-indigo-600 transition-colors"><Edit2 size={18} /></button>
            {isManagement && (
              <button onClick={onDelete} className="p-2 text-gray-400 hover:text-red-600 transition-colors">
                <Trash2 size={18} />
              </button>
            )}
          </div>
        )}
      </div>
      
      <h3 className="text-xl font-bold mb-1">{worker.name}</h3>
      <p className="text-gray-500 text-sm mb-2">{worker.role}</p>
      
      {/* Performance Indicators for Admins */}
      {isManagement && (
        <div className="grid grid-cols-2 gap-2 mb-4">
          <div className="bg-emerald-50 p-2 rounded-xl border border-emerald-100 text-center">
            <p className="text-[8px] text-emerald-600 font-bold uppercase mb-0.5">نسبة الإنجاز</p>
            <p className="text-sm font-black text-emerald-700">{successRate.toFixed(0)}%</p>
          </div>
          <div className="bg-orange-50 p-2 rounded-xl border border-orange-100 text-center">
            <p className="text-[8px] text-orange-600 font-bold uppercase mb-0.5">عدم الإنجاز</p>
            <p className="text-sm font-black text-orange-700">{nonCompletionRate.toFixed(0)}%</p>
          </div>
        </div>
      )}

      <div className="mb-4 flex items-center justify-between">
        <p className="text-xs text-gray-400 font-mono tracking-wider">{worker.phone}</p>
        <a 
          href={`https://wa.me/${worker.phone.replace(/[^0-9]/g, '')}`} 
          target="_blank" 
          rel="noreferrer"
          className="text-[10px] bg-green-500 text-white px-2 py-1 rounded-lg hover:bg-green-600 transition-colors"
        >
          إرسال تنبيه واتساب
        </a>
      </div>

      {canSeeTasks ? (
        <>
          <div className="space-y-3 pt-4 border-t border-gray-50 pb-4">
            <div className="flex justify-between items-center text-xs">
              <div className="flex items-center gap-2 text-green-600 font-medium">
                <CheckCircle2 size={14} />
                <span>المهام المكتملة</span>
              </div>
              <span className="font-bold">{completed.length}</span>
            </div>
            
            <div className="flex justify-between items-center text-xs">
              <div className="flex items-center gap-2 text-indigo-600 font-medium">
                <Circle size={14} />
                <span>تحت التنفيذ</span>
              </div>
              <span className="font-bold">{inProgress.length}</span>
            </div>

            <div className="flex justify-between items-center text-xs">
              <div className="flex items-center gap-2 text-orange-600 font-medium">
                <AlertCircle size={14} />
                <span>غير منجزة</span>
              </div>
              <span className="bg-orange-50 text-orange-700 px-2 py-0.5 rounded-full font-bold">{uncompleted.length}</span>
            </div>

            <div className="flex justify-between items-center text-xs">
              <div className="flex items-center gap-2 text-red-600 font-medium">
                <AlertCircle size={14} />
                <span>مهام متأخرة</span>
              </div>
              <span className="bg-red-50 text-red-700 px-2 py-0.5 rounded-full font-bold">{overdue.length}</span>
            </div>
          </div>

          <button 
            onClick={() => setShowTasks(!showTasks)}
            className="w-full py-2.5 mt-2 bg-gray-50 text-gray-600 text-xs font-bold rounded-xl flex items-center justify-center gap-2 hover:bg-gray-100 transition-all border border-gray-100"
          >
            {showTasks ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
            {showTasks ? 'إخفاء تفاصيل المهام' : 'استعراض جميع المهام'}
          </button>

          {isManagement && onViewAssets && (
            <button 
              onClick={onViewAssets}
              className="w-full py-2.5 mt-2 bg-amber-50 text-amber-700 text-xs font-black rounded-xl flex items-center justify-center gap-2 hover:bg-amber-100 transition-all border border-amber-100"
            >
              <Package size={16} />
              <span>استعراض العُهد والمعدات</span>
            </button>
          )}

          <AnimatePresence>
            {showTasks && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: 'auto', opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                className="overflow-hidden"
              >
                <div className="mt-4 pt-4 border-t border-gray-50 space-y-2">
                  {tasks.length === 0 ? (
                    <p className="text-center py-4 text-gray-400 italic text-[10px]">لا توجد مهام مسجلة</p>
                  ) : (
                    tasks.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()).map(task => {
                      const detailStatus = getTaskDetailedStatus(task);
                      return (
                        <div key={task.id} className="p-3 bg-gray-50 rounded-xl border border-gray-100">
                          <div className="flex items-start justify-between gap-2">
                            <p className={`text-xs font-bold ${detailStatus === 'completed' ? 'text-green-600 line-through' : 'text-gray-800'}`}>
                              {task.title}
                            </p>
                            <span className={`text-[8px] px-1.5 py-0.5 rounded-md font-black uppercase ${
                              task.status === 'review' ? 'bg-amber-100 text-amber-700' :
                              detailStatus === 'completed' ? 'bg-green-100 text-green-700' :
                              detailStatus === 'uncompleted' ? 'bg-orange-100 text-orange-700' :
                              detailStatus === 'overdue' ? 'bg-red-100 text-red-700' : 'bg-indigo-100 text-indigo-700'
                            }`}>
                              {task.status === 'review' ? 'بانتظار الاعتماد' :
                               detailStatus === 'completed' ? 'تم الاعتماد' : 
                               detailStatus === 'uncompleted' ? 'غير منجزة' : 
                               detailStatus === 'overdue' ? 'متأخرة' : 'نشط'}
                            </span>
                          </div>
                          
                          {task.confirmedBy && (
                            <div className="flex items-center gap-1 mt-1 text-[8px] text-emerald-600 font-bold">
                              <ShieldCheck size={10} />
                              <span>تم الاعتماد بواسطة: {task.confirmedBy}</span>
                            </div>
                          )}

                          <div className="mt-2 flex items-center justify-between">
                            <div className="flex items-center gap-1 text-[9px] text-gray-400">
                              <Clock size={10} />
                              <span>البدء: {new Date(task.startTime).toLocaleString('ar-EG')}</span>
                            </div>
                            {task.status === 'review' && isManagement && (
                              <div className="flex gap-1">
                                <button 
                                  onClick={() => handleRejectTask(task.id)}
                                  className="bg-rose-100 text-rose-700 px-2 py-1 rounded-md text-[9px] font-bold hover:bg-rose-200 transition-colors border border-rose-200"
                                >
                                  رفض
                                </button>
                                <button 
                                  onClick={() => handleApproveTask(task.id)}
                                  className="bg-emerald-600 text-white px-2 py-1 rounded-md text-[9px] font-bold hover:bg-emerald-700 transition-colors shadow-sm"
                                >
                                  اعتماد الإنجاز
                                </button>
                              </div>
                            )}
                          </div>
                        </div>
                      )
                    })
                  )}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </>
      ) : (
        <div className="mt-4 pt-4 border-t border-gray-50 text-center">
          <p className="text-[10px] text-gray-400 italic">تفاصيل المهام متاحة للمسؤول فقط</p>
        </div>
      )}
    </div>
  );
};
