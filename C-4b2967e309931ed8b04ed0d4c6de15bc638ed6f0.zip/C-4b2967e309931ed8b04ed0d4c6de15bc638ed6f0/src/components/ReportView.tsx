import React from 'react';
import { Worker } from '../types';
import { Download, CheckCircle2, Circle, Search, Printer, FileDown, ChevronDown } from 'lucide-react';

interface ReportProps {
  workers: Worker[];
}

export const ReportView: React.FC<ReportProps> = ({ workers }) => {
  const [selectedWorkerId, setSelectedWorkerId] = React.useState<string>('all');
  
  const filteredWorkers = workers.filter(w => 
    selectedWorkerId === 'all' || w.id === selectedWorkerId
  );

  const handlePrint = () => {
    window.print();
  };

  const exportToCSV = () => {
    const headers = ['الاسم', 'الصفة', 'رقم الهاتف', 'المهام'];
    const rows = filteredWorkers.map(w => [
      `"${w.name}"`,
      `"${w.role}"`,
      `"${w.phone}"`,
      `"${(w.tasks || []).map(t => `${t.title} (${new Date(t.startTime).toLocaleString('ar-EG')} - ${new Date(t.endTime).toLocaleString('ar-EG')}) [${t.status}]`).join(' | ')}"`
    ]);

    const csvContent = "\uFEFF" + [headers, ...rows].map(e => e.join(",")).join("\n");
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement("a");
    const url = URL.createObjectURL(blob);
    link.style.display = 'none';
    link.setAttribute("href", url);
    link.setAttribute("download", `تقرير_العاملين_${new Date().toLocaleDateString('ar-EG')}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-8 bg-white p-4 sm:p-8 rounded-3xl shadow-sm border border-gray-100 min-h-screen">
      {/* Actions */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-6 print:hidden bg-gray-50 p-6 rounded-[2rem] border border-gray-100">
        <div className="flex-1 space-y-2">
          <div className="flex items-center gap-2 mb-1">
            <Search size={14} className="text-indigo-500" />
            <label className="text-xs font-black text-gray-400 uppercase tracking-widest block">نطاق التقرير المطلوب:</label>
          </div>
          <div className="relative group">
            <select 
              value={selectedWorkerId}
              onChange={(e) => setSelectedWorkerId(e.target.value)}
              className="w-full px-5 py-4 rounded-2xl bg-white border border-gray-200 focus:ring-4 focus:ring-indigo-500/10 outline-none transition-all text-sm font-black text-gray-700 shadow-sm appearance-none hover:border-indigo-300"
            >
              <option value="all">📊 تقرير تحليلي شامل (جميع الكادر)</option>
              {workers.map(w => (
                <option key={w.id} value={w.id}>👤 تقرير فردي: {w.name} ({w.role})</option>
              ))}
            </select>
            <div className="absolute left-4 top-1/2 -translate-y-1/2 pointer-events-none text-gray-400">
              <ChevronDown size={20} />
            </div>
          </div>
        </div>
        <div className="flex flex-col sm:flex-row gap-3 pt-4 sm:pt-0">
          <button 
            onClick={exportToCSV}
            className="flex items-center justify-center gap-3 px-6 py-4 bg-white border-2 border-indigo-100 text-indigo-600 rounded-2xl hover:bg-indigo-50 hover:border-indigo-200 transition-all font-black text-xs shadow-sm active:scale-95"
          >
            <FileDown size={20} />
            <span>تصدير Excel (CSV)</span>
          </button>
          <button 
            onClick={handlePrint}
            className="flex items-center justify-center gap-3 px-8 py-4 bg-indigo-600 text-white rounded-2xl hover:bg-indigo-700 transition-all shadow-xl shadow-indigo-100 font-black text-xs active:scale-95 border-b-4 border-b-indigo-800"
          >
            <Printer size={20} />
            <span>طباعة / حفظ PDF</span>
          </button>
        </div>
      </div>

      <div id="report-content" className="space-y-12">
        <header className="text-center space-y-2 mb-12">
          <h2 className="text-2xl sm:text-3xl font-black text-gray-900">تقرير أداء الكوادر</h2>
          <p className="text-xs sm:text-base text-gray-500 font-bold uppercase tracking-widest">إصدار التاريخ: {new Date().toLocaleDateString('ar-EG')}</p>
          <div className="w-24 h-1 bg-indigo-600 mx-auto mt-4 rounded-full"></div>
        </header>

        {filteredWorkers.map(worker => {
          const tasks = worker.tasks || [];
          const now = new Date();
          
          const getTaskStatus = (task: any) => {
            if (task.status === 'completed') return 'completed';
            const startTime = new Date(task.startTime).getTime();
            const diffHours = (now.getTime() - startTime) / (1000 * 60 * 60);
            if (diffHours >= 24) return 'uncompleted';
            if (diffHours >= 5) return 'overdue';
            return 'in-progress';
          };

          const completed = tasks.filter(t => getTaskStatus(t) === 'completed');
          const uncompleted = tasks.filter(t => getTaskStatus(t) === 'uncompleted');
          const overdue = tasks.filter(t => getTaskStatus(t) === 'overdue');

          const totalTasks = tasks.length;
          const successRate = totalTasks > 0 ? (completed.length / totalTasks) * 100 : 0;
          const failureRate = totalTasks > 0 ? ((totalTasks - completed.length) / totalTasks) * 100 : 0;

          return (
            <div key={worker.id} className="border-b border-gray-100 pb-12 last:border-0 page-break-after">
              <div className="flex flex-col md:flex-row justify-between items-start gap-6 mb-8">
                <div className="flex-1 w-full">
                  <h3 className="text-xl sm:text-2xl font-black text-gray-900">{worker.name}</h3>
                  <p className="text-indigo-600 font-bold mb-1 text-sm">{worker.role}</p>
                  <p className="text-[10px] text-gray-400 font-mono tracking-widest">{worker.phone}</p>
                  
                  <div className="mt-4 grid grid-cols-2 gap-3 max-w-sm">
                    <div className="bg-emerald-50 p-2 rounded-xl border border-emerald-100">
                      <span className="text-[8px] text-emerald-600 font-black block uppercase">نسبة الإنجاز</span>
                      <span className="text-sm font-black text-emerald-700">{successRate.toFixed(0)}%</span>
                    </div>
                    <div className="bg-rose-50 p-2 rounded-xl border border-rose-100">
                      <span className="text-[8px] text-rose-600 font-black block uppercase">نسبة التقصير</span>
                      <span className="text-sm font-black text-rose-700">{failureRate.toFixed(0)}%</span>
                    </div>
                  </div>
                </div>
                <div className="w-full md:w-auto">
                  <div className="grid grid-cols-3 gap-2 p-3 bg-gray-50 rounded-2xl">
                    <div className="text-center px-2">
                      <span className="block text-[8px] text-gray-500 font-black uppercase">منجز</span>
                      <span className="text-lg font-black text-green-600">{completed.length}</span>
                    </div>
                    <div className="text-center px-2 border-x border-gray-200">
                      <span className="block text-[8px] text-gray-500 font-black uppercase">متأخر</span>
                      <span className="text-lg font-black text-red-600">{overdue.length}</span>
                    </div>
                    <div className="text-center px-2">
                      <span className="block text-[8px] text-gray-500 font-black uppercase">غير منجز</span>
                      <span className="text-lg font-black text-orange-600">{uncompleted.length}</span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <h4 className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2">سجل المهام والعمليات</h4>
                <div className="grid grid-cols-1 gap-2">
                  {tasks.length > 0 ? tasks.sort((a,b) => new Date(b.startTime).getTime() - new Date(a.startTime).getTime()).map((t, i) => {
                    const status = getTaskStatus(t);
                    const isReview = t.status === 'review';
                    
                    return (
                      <div key={i} className={`flex flex-col sm:flex-row sm:items-center justify-between text-xs p-4 rounded-xl border gap-3 ${
                        t.status === 'completed' ? 'bg-green-50/50 border-green-100' : 
                        isReview ? 'bg-amber-50/50 border-amber-100' :
                        status === 'uncompleted' ? 'bg-orange-50/50 border-orange-100' :
                        status === 'overdue' ? 'bg-red-50/50 border-red-100' : 
                        'bg-gray-50 border-gray-100'
                      }`}>
                        <div>
                          <p className={`font-bold text-sm ${t.status === 'completed' ? 'line-through text-gray-400' : 'text-gray-900'}`}>{t.title}</p>
                          <p className="text-[9px] text-gray-400 mt-1 font-medium">الموعد: {new Date(t.startTime).toLocaleString('ar-EG', { dateStyle: 'short', timeStyle: 'short' })}</p>
                        </div>
                        <span className={`self-start sm:self-auto px-2 py-0.5 rounded font-black text-[9px] uppercase shadow-sm ${
                          t.status === 'completed' ? 'bg-green-600 text-white' : 
                          isReview ? 'bg-amber-500 text-white' :
                          status === 'uncompleted' ? 'bg-orange-600 text-white' :
                          status === 'overdue' ? 'bg-red-600 text-white' : 
                          'bg-indigo-600 text-white'
                        }`}>
                          {t.status === 'completed' ? 'تم الاعتماد' : 
                           isReview ? 'بانتظار المراجعة' :
                           status === 'uncompleted' ? 'لم تكتمل' : 
                           status === 'overdue' ? 'متأخرة جداً' : 
                           'قيد العمل'}
                        </span>
                      </div>
                    );
                  }) : <p className="text-gray-300 italic text-[10px]">لا توجد مهام مسجلة لهذا العامل</p>}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      <style>{`
        @media print {
          body { background: white !important; }
          .print\\:hidden { display: none !important; }
          #root { max-width: 100% !important; padding: 0 !important; }
          .page-break-after { page-break-after: always; }
          .rounded-3xl { border-radius: 0 !important; }
          .shadow-sm { box-shadow: none !important; }
          .border { border: none !important; border-bottom: 1px solid #eee !important; }
        }
      `}</style>
    </div>
  );
};
