import React from 'react';
import { db } from '../lib/firebase';
import { collection, addDoc, getDocs, deleteDoc, doc, onSnapshot, query, serverTimestamp, updateDoc } from 'firebase/firestore';
import { UserPlus, Trash2, Shield, UserCircle2, Edit2, X } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export const UserManagement: React.FC = () => {
  const [users, setUsers] = React.useState<any[]>([]);
  const [username, setUsername] = React.useState('');
  const [password, setPassword] = React.useState('');
  const [role, setRole] = React.useState<'admin' | 'worker'>('worker');
  const [jobTitle, setJobTitle] = React.useState('');
  const [loading, setLoading] = React.useState(true);
  const [editingUserId, setEditingUserId] = React.useState<string | null>(null);

  React.useEffect(() => {
    const q = query(collection(db, 'users'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      setUsers(snapshot.docs.map(d => ({ id: d.id, ...d.data() })));
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  const handleEditClick = (u: any) => {
    setEditingUserId(u.id);
    setUsername(u.username);
    setPassword(u.password);
    setRole(u.role);
    setJobTitle(u.jobTitle || '');
  };

  const handleCancelEdit = () => {
    setEditingUserId(null);
    setUsername('');
    setPassword('');
    setRole('worker');
    setJobTitle('');
  };

  const handleAddUser = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!username || !password) return;

    try {
      const isDuplicate = users.some(u => 
        u.username.toLowerCase() === username.trim().toLowerCase() && u.id !== editingUserId
      );

      if (isDuplicate) {
        alert('اسم المستخدم هذا مسجل مسبقاً، يرجى اختيار اسم آخر');
        return;
      }

      if (editingUserId) {
        // Update User Doc
        await updateDoc(doc(db, 'users', editingUserId), {
          username: username.trim(),
          password: password,
          role,
          jobTitle: jobTitle.trim(),
          updatedAt: serverTimestamp()
        });

        // Sync with workers collection if worker
        if (role === 'worker' && jobTitle) {
          const workersSnapshot = await getDocs(query(collection(db, 'workers')));
          // Rule: Look for worker whose role matches the new job title
          const existingWorker = workersSnapshot.docs.find(d => 
            d.data().role.trim().toLowerCase() === jobTitle.trim().toLowerCase()
          );

          if (!existingWorker) {
            // Create new worker profile if no worker has this job title yet
            await addDoc(collection(db, 'workers'), {
              name: username.trim(),
              role: jobTitle.trim(),
              phone: '',
              tasks: [],
              createdAt: serverTimestamp(),
              updatedAt: serverTimestamp()
            });
          } else {
            // Update existing worker by title to match the new username
            await updateDoc(doc(db, 'workers', existingWorker.id), {
              name: username.trim(),
              updatedAt: serverTimestamp()
            });
          }
        }
        
        setEditingUserId(null);
        alert('تم تحديث بيانات المستخدم بنجاح ومزامنة ملف العامل');
      } else {
        // Create user
        await addDoc(collection(db, 'users'), {
          username: username.trim(),
          password,
          role,
          jobTitle: jobTitle.trim(),
          createdAt: new Date().toISOString()
        });

        // Auto-link or create worker profile
        if (role === 'worker' && jobTitle) {
          const workersSnapshot = await getDocs(query(collection(db, 'workers')));
          // Rule: Look for worker whose role matches the provided job title
          const existingWorker = workersSnapshot.docs.find(d => 
            d.data().role.trim().toLowerCase() === jobTitle.trim().toLowerCase()
          );

          if (!existingWorker) {
            await addDoc(collection(db, 'workers'), {
              name: username.trim(),
              role: jobTitle.trim(),
              phone: '',
              tasks: [],
              createdAt: serverTimestamp(),
              updatedAt: serverTimestamp()
            });
          } else {
            // Match found by job title - update name to this username
            await updateDoc(doc(db, 'workers', existingWorker.id), {
              name: username.trim(),
              updatedAt: serverTimestamp()
            });
          }
        }
        alert('تم إضافة المستخدم بنجاح وإنشاء/تحديث ملف العامل');
      }

      setUsername('');
      setPassword('');
      setJobTitle('');
      setRole('worker');
    } catch (err) {
      console.error(err);
      alert('فشل في معالجة الطلب');
    }
  };

  const handleDeleteUser = async (id: string, name: string) => {
    if (!confirm(`هل أنت متأكد من حذف المستخدم ${name}؟ في حال كان هذا المستخدم (عامل)، سيتم أيضاً حذف ملفه الشخصي ومهامه.`)) return;
    try {
      // Delete User Doc
      await deleteDoc(doc(db, 'users', id));

      // Sync Delete with Worker profile if it exists
      const workersSnapshot = await getDocs(query(collection(db, 'workers')));
      const workerDoc = workersSnapshot.docs.find(d => 
        d.data().name.trim().toLowerCase() === name.trim().toLowerCase()
      );
      if (workerDoc) {
        await deleteDoc(doc(db, 'workers', workerDoc.id));
      }
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 pb-20 sm:pb-0">
      {/* Form */}
      <div className="bg-white p-6 sm:p-8 rounded-3xl shadow-sm border border-gray-100 flex flex-col h-fit order-2 lg:order-1">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-indigo-50 text-indigo-600 rounded-lg">
              {editingUserId ? <Edit2 size={24} /> : <UserPlus size={24} />}
            </div>
            <h3 className="text-xl font-bold">{editingUserId ? 'تعديل مستخدم' : 'إضافة مستخدم'}</h3>
          </div>
          {editingUserId && (
            <button onClick={handleCancelEdit} className="p-2 text-gray-400 hover:bg-gray-100 rounded-full">
              <X size={20} />
            </button>
          )}
        </div>

        <form onSubmit={handleAddUser} className="space-y-4">
          <div className="space-y-2">
            <label className="text-xs font-bold text-gray-500">اسم المستخدم</label>
            <input 
              type="text" 
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full px-4 py-3 bg-gray-50 rounded-xl border border-gray-100 outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all text-sm"
              placeholder="Username..."
              required
            />
          </div>
          <div className="space-y-2">
            <label className="text-xs font-bold text-gray-500">كلمة المرور</label>
            <input 
              type="password" 
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-4 py-3 bg-gray-50 rounded-xl border border-gray-100 outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all text-sm"
              placeholder="Password..."
              required
            />
          </div>
          <div className="space-y-2">
            <label className="text-xs font-bold text-gray-500">المسمى الوظيفي</label>
            <input 
              type="text" 
              value={jobTitle}
              onChange={(e) => setJobTitle(e.target.value)}
              className="w-full px-4 py-3 bg-gray-50 rounded-xl border border-gray-100 outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all text-sm"
              placeholder="مثال: مصور، محرر..."
              required={role === 'worker'}
            />
          </div>
          <div className="space-y-2">
            <label className="text-xs font-bold text-gray-500">الصلاحيات</label>
            <select 
              value={role}
              onChange={(e) => setRole(e.target.value as any)}
              className="w-full px-4 py-3 bg-gray-50 rounded-xl border border-gray-100 outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all text-sm"
            >
              <option value="admin">صلاحيات عامة (مسؤول Admin)</option>
              <option value="worker">صلاحيات خاصة (عامل/موظف)</option>
            </select>
          </div>
          <p className="text-[10px] text-gray-400">ملاحظة: الصلاحيات الخاصة تتيح للمستخدم رؤية مهامه الشخصية فقط بناءً على المسمى الوظيفي والاسم.</p>
          <button 
            type="submit"
            className={`w-full text-white font-bold py-3.5 rounded-xl transition-all shadow-md active:scale-95 mt-4 ${
              editingUserId ? 'bg-indigo-500 hover:bg-indigo-600' : 'bg-indigo-600 hover:bg-indigo-700'
            }`}
          >
            {editingUserId ? 'تحديث البيانات' : 'حفظ المستخدم'}
          </button>
        </form>
      </div>

      {/* List */}
      <div className="lg:col-span-2 bg-white p-6 sm:p-8 rounded-3xl shadow-sm border border-gray-100 order-1 lg:order-2">
        <h3 className="text-xl font-bold mb-6">المستخدمون الحاليون</h3>
        
        <div className="space-y-3">
          <AnimatePresence>
            {users.length === 0 && !loading ? (
              <p className="text-center py-12 text-gray-400">لا يوجد مستخدمون مضافون حالياً</p>
            ) : (
              users.map((u) => (
                <motion.div 
                  key={u.id}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="flex flex-col sm:flex-row sm:items-center justify-between p-4 bg-gray-50 rounded-2xl border border-gray-100 group gap-4"
                >
                  <div className="flex items-center gap-3">
                    <div className="relative">
                      <UserCircle2 size={32} className="text-gray-300" />
                      {u.isOnline && (
                        <span className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 border-2 border-white rounded-full"></span>
                      )}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <p className="font-bold text-gray-900">{u.username}</p>
                        <div className="flex flex-col gap-1 items-start">
                          <div className="flex items-center gap-1 text-[9px] text-indigo-500 font-bold uppercase border border-indigo-100 px-1.5 py-0.5 rounded">
                            {u.role === 'admin' ? 'مسؤول' : 'عامل'}
                          </div>
                          {u.jobTitle && <p className="text-[10px] text-gray-500 font-medium">{u.jobTitle}</p>}
                        </div>
                      </div>
                      <p className="text-[10px] text-gray-400">
                        {u.isOnline ? 'متصل الآن' : `آخر ظهور: ${u.lastSeen ? new Date(u.lastSeen).toLocaleString('ar-EG') : 'غير متوفر'}`}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 sm:opacity-0 sm:group-hover:opacity-100 transition-all self-end sm:self-auto">
                    <button 
                      onClick={() => handleEditClick(u)}
                      className="p-2.5 bg-white text-indigo-400 hover:text-indigo-600 rounded-xl transition-all border border-gray-100 shadow-sm sm:border-0 sm:shadow-none sm:bg-transparent"
                      title="تعديل"
                    >
                      <Edit2 size={18} />
                    </button>
                    <button 
                      onClick={() => handleDeleteUser(u.id, u.username)}
                      className="p-2.5 bg-white text-red-400 hover:text-red-600 rounded-xl transition-all border border-gray-100 shadow-sm sm:border-0 sm:shadow-none sm:bg-transparent"
                      title="حذف"
                    >
                      <Trash2 size={18} />
                    </button>
                  </div>
                </motion.div>
              ))
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
};
