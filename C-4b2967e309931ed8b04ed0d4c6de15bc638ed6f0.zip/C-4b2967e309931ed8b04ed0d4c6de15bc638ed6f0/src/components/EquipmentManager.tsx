import React from 'react';
import { collection, query, onSnapshot, addDoc, updateDoc, doc, serverTimestamp, orderBy, deleteDoc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { Asset, Worker } from '../types';
import { Package, Plus, History, Undo2, User, Calendar, Search, Filter, Trash2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface EquipmentManagerProps {
  workers: Worker[];
  initialSearch?: string;
  currentUser: any;
}

export const EquipmentManager: React.FC<EquipmentManagerProps> = ({ workers, initialSearch = '', currentUser }) => {
  const [assets, setAssets] = React.useState<Asset[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [showAddForm, setShowAddForm] = React.useState(false);
  const [typeFilter, setTypeFilter] = React.useState('all');
  const [statusTab, setStatusTab] = React.useState<'active' | 'returned'>('active');
  const [searchTerm, setSearchTerm] = React.useState(initialSearch);

  React.useEffect(() => {
    setSearchTerm(initialSearch);
  }, [initialSearch]);

  const [formData, setFormData] = React.useState({
    workerId: '',
    type: '',
    specifications: '',
    handedOverBy: currentUser.username || '',
    receivedAt: new Date().toISOString().split('T')[0]
  });

  React.useEffect(() => {
    if (!formData.handedOverBy && currentUser.username) {
      setFormData(prev => ({ ...prev, handedOverBy: currentUser.username }));
    }
  }, [currentUser.username]);

  React.useEffect(() => {
    const q = query(collection(db, 'assets'), orderBy('createdAt', 'desc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const data = snapshot.docs.map(d => ({ id: d.id, ...d.data() } as Asset));
      setAssets(data);
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  const handleAddAsset = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.workerId || !formData.type || !formData.handedOverBy) return;

    const worker = workers.find(w => w.id === formData.workerId);
    
    try {
      await addDoc(collection(db, 'assets'), {
        ...formData,
        workerName: worker?.name || 'غير معروف',
        status: 'active',
        returnedAt: null,
        createdAt: serverTimestamp()
      });
      setShowAddForm(false);
      setFormData({
        workerId: '',
        type: '',
        specifications: '',
        handedOverBy: currentUser.username || '',
        receivedAt: new Date().toISOString().split('T')[0]
      });
    } catch (err) {
      console.error(err);
      alert('فشل في إضافة العهدة');
    }
  };

  const [returningAssetId, setReturningAssetId] = React.useState<string | null>(null);
  const [returnDetails, setReturnDetails] = React.useState({
    date: new Date().toISOString().split('T')[0],
    condition: 'سليمة',
    receivedBy: currentUser.username || ''
  });

  const handleReturnAsset = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!returningAssetId) return;
    
    try {
      await updateDoc(doc(db, 'assets', returningAssetId), {
        status: 'returned',
        returnedAt: returnDetails.date,
        returnCondition: returnDetails.condition,
        receivedBackBy: returnDetails.receivedBy,
        updatedAt: serverTimestamp()
      });
      setReturningAssetId(null);
      alert('تم استلام العهدة وتوثيق الحالة بنجاح');
    } catch (err) {
      console.error(err);
      alert('فشل في تحديث حالة العهدة');
    }
  };

  const handleDeleteAsset = async (assetId: string) => {
    if (!confirm('هل أنت متأكد من حذف هذا السجل نهائياً من الأرشيف؟')) return;
    try {
      await deleteDoc(doc(db, 'assets', assetId));
    } catch (err) {
      console.error(err);
      alert('فشل في حذف السجل');
    }
  };

  const handleClearArchive = async () => {
    if (!confirm('هل أنت متأكد من مسح جميع بيانات الأرشيف (العُهد المستلمة) نهائياً؟')) return;
    try {
      const archivedAssets = assets.filter(a => a.status === 'returned');
      for (const asset of archivedAssets) {
        if (asset.id) {
          await deleteDoc(doc(db, 'assets', asset.id));
        }
      }
      alert('تم مسح الأرشيف بنجاح');
    } catch (err) {
      console.error(err);
      alert('فشل في مسح البعض أو كل بيانات الأرشيف');
    }
  };

  const filteredAssets = assets.filter(a => {
    const matchesStatus = a.status === statusTab;
    const matchesType = typeFilter === 'all' || a.type === typeFilter;
    const matchesSearch = a.workerName.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          a.type.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          (a.specifications || '').toLowerCase().includes(searchTerm.toLowerCase());
    return matchesStatus && matchesType && matchesSearch;
  });

  const activeCount = assets.filter(a => a.status === 'active').length;
  const returnedCount = assets.filter(a => a.status === 'returned').length;

  const assetTypes = ['كاميرا فوتوغرافية', 'كاميرا فيديو', 'مايكروفون', 'جهاز كمبيوتر', 'هارد', 'ذاكرة', 'حامل', 'أخرى'];

  if (loading) return (
    <div className="flex items-center justify-center py-20">
      <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
    </div>
  );

  return (
    <div className="space-y-8 pb-20">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-white p-6 rounded-3xl border border-gray-100 shadow-sm">
        <div>
          <h2 className="text-2xl font-black text-gray-900 mb-1">نظام إدارة العُهد</h2>
          <p className="text-gray-500 font-medium text-sm">تتبع المعدات المسلّمة للكادر وتوثيق الاستلام والإعادة.</p>
        </div>
        <button 
          onClick={() => setShowAddForm(!showAddForm)}
          className="flex items-center gap-2 px-6 py-3 bg-indigo-600 text-white rounded-2xl font-bold hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100"
        >
          {showAddForm ? <Undo2 size={20} /> : <Plus size={20} />}
          <span>{showAddForm ? 'إلغاء' : 'صرف عهدة جديدة'}</span>
        </button>
      </div>

      <AnimatePresence>
        {showAddForm && (
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="bg-white p-8 rounded-[2.5rem] border border-indigo-50 shadow-xl shadow-indigo-50/50"
          >
            <form onSubmit={handleAddAsset} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="space-y-2">
                <label className="text-xs font-black text-gray-400 uppercase tracking-widest mr-2">الموظف المستلم</label>
                <select 
                  value={formData.workerId}
                  onChange={(e) => setFormData({...formData, workerId: e.target.value})}
                  className="w-full px-4 py-3.5 bg-gray-50 rounded-xl border border-gray-100 outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all text-sm font-bold"
                  required
                >
                  <option value="">اختر الموظف...</option>
                  {workers.map(w => (
                    <option key={w.id} value={w.id}>{w.name} ({w.role})</option>
                  ))}
                </select>
              </div>

              <div className="space-y-2">
                <label className="text-xs font-black text-gray-400 uppercase tracking-widest mr-2">نوع العهدة</label>
                <select 
                  value={formData.type}
                  onChange={(e) => setFormData({...formData, type: e.target.value})}
                  className="w-full px-4 py-3.5 bg-gray-50 rounded-xl border border-gray-100 outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all text-sm font-bold"
                  required
                >
                  <option value="">اختر النوع...</option>
                  {assetTypes.map(t => (
                    <option key={t} value={t}>{t}</option>
                  ))}
                </select>
              </div>

              <div className="space-y-2 lg:col-span-2">
                <label className="text-xs font-black text-gray-400 uppercase tracking-widest mr-2">مواصفات المعدّة (الرقم التسلسلي / الموديل)</label>
                <input 
                  type="text"
                  placeholder="مثال: Sony A7III - SN: 12345..."
                  value={formData.specifications}
                  onChange={(e) => setFormData({...formData, specifications: e.target.value})}
                  className="w-full px-4 py-3.5 bg-gray-50 rounded-xl border border-gray-100 outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all text-sm font-bold placeholder:text-gray-300"
                />
              </div>

              <div className="space-y-2">
                <label className="text-xs font-black text-gray-400 uppercase tracking-widest mr-2">تاريخ الاستلام</label>
                <input 
                  type="date"
                  value={formData.receivedAt}
                  onChange={(e) => setFormData({...formData, receivedAt: e.target.value})}
                  className="w-full px-4 py-3.5 bg-gray-50 rounded-xl border border-gray-100 outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all text-sm font-bold"
                  required
                />
              </div>

              <div className="space-y-2">
                <label className="text-xs font-black text-gray-400 uppercase tracking-widest mr-2">الموظف المسلّم</label>
                <input 
                  type="text"
                  placeholder="اسم الشخص المسلّم..."
                  value={formData.handedOverBy}
                  onChange={(e) => setFormData({...formData, handedOverBy: e.target.value})}
                  className="w-full px-4 py-3.5 bg-gray-50 rounded-xl border border-gray-100 outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all text-sm font-bold placeholder:text-gray-300"
                  required
                />
              </div>

              <div className="md:col-span-2 lg:col-span-4 pt-4">
                <button type="submit" className="w-full py-4 bg-gray-900 text-white rounded-2xl font-black text-lg hover:bg-black transition-all shadow-xl">
                  تأكيد صرف العهدة وحفظ البيانات
                </button>
              </div>
            </form>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        <div className="lg:col-span-1 space-y-4">
          <div className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm space-y-6">
            <div>
              <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-3 block">البحث السريع</label>
              <div className="relative">
                <Search size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400" />
                <input 
                  type="text"
                  placeholder="اسم الموظف أو الجهاز..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pr-10 pl-4 py-3 bg-gray-50 text-xs rounded-xl border border-transparent focus:bg-white focus:border-indigo-100 outline-none transition-all"
                />
              </div>
            </div>

            <div>
              <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-3 block">تصنيف حسب النوع</label>
              <div className="space-y-2">
                <button 
                  onClick={() => setTypeFilter('all')}
                  className={`w-full text-right px-4 py-2.5 rounded-xl text-xs font-bold transition-all ${typeFilter === 'all' ? 'bg-indigo-600 text-white shadow-md' : 'hover:bg-gray-50 text-gray-600'}`}
                >
                  الكل
                </button>
                {assetTypes.map(t => (
                  <button 
                    key={t}
                    onClick={() => setTypeFilter(t)}
                    className={`w-full text-right px-4 py-2.5 rounded-xl text-xs font-bold transition-all ${typeFilter === t ? 'bg-indigo-600 text-white shadow-md' : 'hover:bg-gray-50 text-gray-600'}`}
                  >
                    {t}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        <div className="lg:col-span-3 space-y-6">
          {/* Status Tabs */}
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div className="flex p-1.5 bg-gray-100 rounded-2xl w-fit">
              <button 
                onClick={() => setStatusTab('active')}
                className={`flex items-center gap-2 px-6 py-2.5 rounded-xl text-xs font-black transition-all ${statusTab === 'active' ? 'bg-white text-indigo-600 shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}
              >
                <Package size={14} />
                <span>العُهد المسلّمة (الحالية)</span>
                <span className="bg-indigo-50 px-2 py-0.5 rounded-lg text-[10px]">{activeCount}</span>
              </button>
              <button 
                onClick={() => setStatusTab('returned')}
                className={`flex items-center gap-2 px-6 py-2.5 rounded-xl text-xs font-black transition-all ${statusTab === 'returned' ? 'bg-white text-emerald-600 shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}
              >
                <History size={14} />
                <span>الأرشيف (العُهد المستلمة)</span>
                <span className="bg-emerald-50 px-2 py-0.5 rounded-lg text-[10px]">{returnedCount}</span>
              </button>
            </div>

            {statusTab === 'returned' && returnedCount > 0 && (
              <button 
                onClick={handleClearArchive}
                className="flex items-center gap-2 px-4 py-2 text-red-600 hover:bg-red-50 rounded-xl transition-all text-xs font-black"
              >
                <Trash2 size={14} />
                <span>مسح الأرشيف بالكامل</span>
              </button>
            )}
          </div>

          {filteredAssets.length === 0 ? (
            <div className="bg-white p-20 rounded-[3rem] border border-dashed border-gray-200 text-center space-y-4">
              <div className="w-16 h-16 bg-gray-50 rounded-full flex items-center justify-center mx-auto text-gray-300">
                <Package size={32} />
              </div>
              <p className="text-gray-400 font-bold">
                {statusTab === 'active' ? 'لا يوجد عُهد مسلّمة حالياً.' : 'الأرشيف فارغ حالياً.'}
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {filteredAssets.map(asset => (
                <motion.div 
                  key={asset.id}
                  layout
                  className={`p-6 rounded-[2rem] border transition-all hover:shadow-lg ${asset.status === 'active' ? 'bg-white border-gray-100' : 'bg-gray-50/50 border-gray-100 grayscale-[0.5]'}`}
                >
                  <div className="flex justify-between items-start mb-6">
                    <div className={`p-4 rounded-2xl ${asset.status === 'active' ? 'bg-indigo-50 text-indigo-600' : 'bg-gray-100 text-gray-400'}`}>
                      <Package size={24} />
                    </div>
                    <div className="flex flex-col items-end gap-2">
                      <div className={`px-3 py-1 rounded-lg text-[10px] font-black uppercase ${asset.status === 'active' ? 'bg-emerald-50 text-emerald-600' : 'bg-gray-100 text-gray-500'}`}>
                        {asset.status === 'active' ? 'في العهدة' : 'تمت الإعادة'}
                      </div>
                      {asset.status === 'returned' && (
                        <button 
                          onClick={() => asset.id && handleDeleteAsset(asset.id)}
                          className="p-2 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-all"
                          title="حذف من الأرشيف"
                        >
                          <Trash2 size={14} />
                        </button>
                      )}
                    </div>
                  </div>

                  <div className="space-y-4 mb-6">
                    <div>
                      <div className="flex items-center gap-2 text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">
                        <User size={12} />
                        <span>المستلم</span>
                      </div>
                      <p className="text-lg font-black text-gray-900">{asset.workerName}</p>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <div className="flex items-center gap-2 text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">
                          <Filter size={12} />
                          <span>النوع</span>
                        </div>
                        <p className="font-bold text-gray-700">{asset.type}</p>
                      </div>
                      <div>
                        <div className="flex items-center gap-2 text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">
                          <Calendar size={12} />
                          <span>الاستلام</span>
                        </div>
                        <p className="font-bold text-gray-700">{asset.receivedAt}</p>
                      </div>
                    </div>

                    {asset.specifications && (
                      <div className="bg-gray-50 p-3 rounded-xl border border-gray-100">
                        <p className="text-[10px] font-black text-gray-400 uppercase mb-1">المواصفات والتفاصيل:</p>
                        <p className="text-xs font-bold text-gray-600 leading-relaxed">{asset.specifications}</p>
                      </div>
                    )}

                    <div className="pt-4 border-t border-gray-50 grid grid-cols-2 gap-4">
                      <div>
                        <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">المسلّم</p>
                        <p className="text-xs font-bold text-indigo-600">{asset.handedOverBy}</p>
                      </div>
                      {asset.status === 'returned' && (
                        <div>
                          <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">بواسطة</p>
                          <p className="text-xs font-bold text-emerald-600">{asset.receivedBackBy || 'غير مسجل'}</p>
                        </div>
                      )}
                    </div>
                  </div>

                  {asset.status === 'active' ? (
                    <button 
                      onClick={() => setReturningAssetId(asset.id || null)}
                      className="w-full flex items-center justify-center gap-2 py-3 bg-indigo-600 text-white hover:bg-indigo-700 rounded-xl transition-all font-bold text-xs shadow-md shadow-indigo-100"
                    >
                      <History size={14} />
                      <span>تسجيل استلام العهدة</span>
                    </button>
                  ) : (
                    <div className="bg-emerald-50/50 p-4 rounded-2xl border border-emerald-100">
                      <div className="flex justify-between items-center mb-2">
                        <p className="text-[10px] font-black text-emerald-600 uppercase mb-1">حالة العودة ({asset.returnedAt})</p>
                      </div>
                      <p className="text-xs font-bold text-emerald-700 bg-white inline-block px-2 py-1 rounded-lg border border-emerald-50">{asset.returnCondition || 'سليمة'}</p>
                    </div>
                  )}
                </motion.div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Return Confirmation Modal */}
      <AnimatePresence>
        {returningAssetId && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setReturningAssetId(null)}
              className="absolute inset-0 bg-gray-900/60 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="relative bg-white w-full max-w-md rounded-[2.5rem] shadow-2xl overflow-hidden text-right"
            >
              <div className="p-8 space-y-6">
                <div className="w-16 h-16 bg-emerald-50 text-emerald-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <History size={32} />
                </div>
                <div className="text-center">
                  <h3 className="text-xl font-black text-gray-900">تأكيد استلام وفحص العُهدة</h3>
                  <p className="text-gray-500 text-sm mt-1">يُرجى توثيق حالة المعدات وتاريخ الإرجاع الفعلي.</p>
                </div>

                <form onSubmit={handleReturnAsset} className="space-y-4">
                  <div className="space-y-2">
                    <label className="text-xs font-black text-gray-400 uppercase tracking-widest block mr-2">تاريخ الإرجاع</label>
                    <input 
                      type="date"
                      value={returnDetails.date}
                      onChange={(e) => setReturnDetails({...returnDetails, date: e.target.value})}
                      className="w-full px-4 py-3 bg-gray-50 rounded-xl border border-gray-100 outline-none focus:ring-2 focus:ring-emerald-500 font-bold"
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-black text-gray-400 uppercase tracking-widest block mr-2">حالة المعدات</label>
                    <select 
                      value={returnDetails.condition}
                      onChange={(e) => setReturnDetails({...returnDetails, condition: e.target.value})}
                      className="w-full px-4 py-3 bg-gray-50 rounded-xl border border-gray-100 outline-none focus:ring-2 focus:ring-emerald-500 font-bold"
                    >
                      <option value="سليمة">سليمة ومطابقة</option>
                      <option value="بها خدوش">بها خدوش بسيطة</option>
                      <option value="تحتاج صيانة">تحتاج صيانة دورية</option>
                      <option value="عطل فني">يوجد عطل فني</option>
                      <option value="تالفة">تالفة / كسر</option>
                      <option value="أخرى">أخرى (سجل في الملاحظات)</option>
                    </select>
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-black text-gray-400 uppercase tracking-widest block mr-2">الموظف المستلم (المخزن)</label>
                    <input 
                      type="text"
                      value={returnDetails.receivedBy}
                      onChange={(e) => setReturnDetails({...returnDetails, receivedBy: e.target.value})}
                      placeholder="اسم الموظف المستلم للمعدة..."
                      className="w-full px-4 py-3 bg-gray-50 rounded-xl border border-gray-100 outline-none focus:ring-2 focus:ring-emerald-500 font-bold"
                      required
                    />
                  </div>
                  <div className="flex gap-3 pt-4">
                    <button 
                      type="submit"
                      className="flex-1 py-4 bg-emerald-600 text-white rounded-2xl font-black shadow-lg shadow-emerald-100 hover:bg-emerald-700 transition-all"
                    >
                      تأكيد وحفظ البيانات
                    </button>
                    <button 
                      type="button"
                      onClick={() => setReturningAssetId(null)}
                      className="px-6 py-4 bg-gray-100 text-gray-500 rounded-2xl font-bold hover:bg-gray-200 transition-all"
                    >
                      إلغاء
                    </button>
                  </div>
                </form>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
