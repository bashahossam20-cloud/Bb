import React from 'react';
import { Worker, AppUser } from '../types';
import { CheckCircle2, Circle, AlertCircle, Clock, Bell, BellOff, CalendarClock } from 'lucide-react';
import { motion } from 'motion/react';
import { db } from '../lib/firebase';
import { collection, addDoc, serverTimestamp, updateDoc, doc } from 'firebase/firestore';

interface Props {
  workers: Worker[];
  currentUser: AppUser;
}

export const WorkerSelfView: React.FC<Props> = ({ workers, currentUser }) => {
  // Find the worker record that matches current logged in username
  const workerRecord = workers.find(w => w.name === currentUser.username);
  
  const [permission, setPermission] = React.useState<NotificationPermission>(
    typeof Notification !== 'undefined' ? Notification.permission : 'denied'
  );
  const [requestingId, setRequestingId] = React.useState<string | null>(null);
  const [finishingId, setFinishingId] = React.useState<string | null>(null);
  const notifiedTasksRef = React.useRef<Set<string>>(new Set());

  const handleFinishTask = async (task: any) => {
    if (!workerRecord) return;
    setFinishingId(task.id);
    try {
      // Update task status to 'review' in worker document
      const updatedTasks = workerRecord.tasks.map(t => 
        t.id === task.id ? { ...t, status: 'review' as const } : t
      );
      
      await updateDoc(doc(db, 'workers', workerRecord.id), {
        tasks: updatedTasks,
        updatedAt: serverTimestamp()
      });

      // Send notification message to admins
      await addDoc(collection(db, 'messages'), {
        sender: currentUser.username,
        recipientId: 'admin_broadcast',
        text: `تم إنجاز المهمة: "${task.title}" - يرجى المراجعة والاعتماد.`,
        createdAt: serverTimestamp()
      });

      alert('تم إرسال المهمة للمراجعة. سيتم اعتمادها من قبل الإدارة قريباً.');
    } catch (error) {
      console.error('Error finishing task:', error);
      alert('فشل إرسال طلب الإنجاز، يرجى المحاولة لاحقاً');
    } finally {
      setFinishingId(null);
    }
  };

  const requestPermission = async () => {
    if (typeof Notification !== 'undefined') {
      const result = await Notification.requestPermission();
      setPermission(result);
    }
  };

  const tasks = workerRecord?.tasks || [];

  const handleRequestExtension = async (taskTitle: string, taskId: string) => {
    setRequestingId(taskId);
    try {
      await addDoc(collection(db, 'messages'), {
        sender: currentUser.username,
        recipientId: 'admin_broadcast',
        text: `طلب تمديد للمهمة: "${taskTitle}" - المهلة انتهت وأحتاج لمزيد من الوقت.`,
        createdAt: serverTimestamp()
      });
      alert('تم إرسال طلب التمديد للإدارة');
    } catch (error) {
      console.error('Error sending request:', error);
      alert('فشل إرسال الطلب، يرجى المحاولة لاحقاً');
    } finally {
      setRequestingId(null);
    }
  };

  React.useEffect(() => {
    if (permission !== 'granted' || !workerRecord) return;

    const checkTasks = () => {
      const now = new Date();
      tasks.forEach(task => {
        if (task.status === 'completed' || task.status === 'review') return;

        const startTime = new Date(task.startTime).getTime();
        const diffHours = (now.getTime() - startTime) / (1000 * 60 * 60);

        // Warning: Been active for > 4 hours
        if (diffHours >= 4 && diffHours < 5 && !notifiedTasksRef.current.has(`${task.id}-soon`)) {
          new Notification('تنبيه: مهمة اقتربت من التأخير', {
            body: `المهمة "${task.title}" بدأت منذ 4 ساعات، يرجى إنجازها قريباً.`,
          });
          notifiedTasksRef.current.add(`${task.id}-soon`);
        }

        // Overdue: Been active for > 5 hours
        if (diffHours >= 5 && !notifiedTasksRef.current.has(`${task.id}-overdue`)) {
          new Notification('تنبيه: مهمة متأخرة', {
            body: `المهمة "${task.title}" تجاوزت 5 ساعات منذ إنشائها.`,
          });
          notifiedTasksRef.current.add(`${task.id}-overdue`);
        }
      });
    };

    const interval = setInterval(checkTasks, 60000);
    checkTasks(); // Immediate check
    return () => clearInterval(interval);
  }, [tasks, permission, workerRecord]);

  if (!workerRecord) {
    return (
      <div className="bg-white p-12 rounded-3xl border border-gray-100 shadow-sm text-center">
        <div className="w-16 h-16 bg-orange-50 text-orange-500 rounded-full flex items-center justify-center mx-auto mb-4">
          <AlertCircle size={32} />
        </div>
        <h3 className="text-xl font-bold">لم يتم العثور على سجل عامل متاح</h3>
        <p className="text-gray-500 mt-2 max-w-sm mx-auto">
          يرجى التأكد من أن اسم المستخدم الخاص بك ({currentUser.username}) يتطابق تماماً مع اسم العامل المسجل في قائمة الكوادر.
        </p>
      </div>
    );
  }

  const now = new Date();
  
  const getDetailedStatus = (task: any) => {
    if (task.status === 'completed') return 'completed';
    if (task.status === 'review') return 'review';
    const startTime = new Date(task.startTime).getTime();
    const diffHours = (now.getTime() - startTime) / (1000 * 60 * 60);
    
    if (diffHours >= 24) return 'uncompleted';
    if (diffHours >= 5) return 'overdue';
    return 'in-progress';
  };

  const completed = tasks.filter(t => getDetailedStatus(t) === 'completed');
  const inProgress = tasks.filter(t => getDetailedStatus(t) === 'in-progress');
  const overdue = tasks.filter(t => getDetailedStatus(t) === 'overdue');
  const uncompleted = tasks.filter(t => getDetailedStatus(t) === 'uncompleted');

  const totalTasks = tasks.length;
  const successRate = totalTasks > 0 ? (completed.length / totalTasks) * 100 : 0;
  const nonCompletionRate = totalTasks > 0 ? ((totalTasks - completed.length) / totalTasks) * 100 : 0;

  return (
    <div className="space-y-6">
      <div className="bg-white p-4 rounded-3xl border border-gray-100 shadow-sm flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className={`p-2 rounded-xl ${permission === 'granted' ? 'bg-green-100 text-green-600' : 'bg-orange-100 text-orange-600'}`}>
            {permission === 'granted' ? <Bell size={20} /> : <BellOff size={20} />}
          </div>
          <div>
            <p className="text-sm font-bold text-gray-800">
              {permission === 'granted' ? 'التنبيهات مفعلة' : 'التنبيهات معطلة'}
            </p>
            <p className="text-[10px] text-gray-500">سوف نصلك إخطار عند قرب انتهاء المهام أو تأخرها</p>
          </div>
        </div>
        {permission !== 'granted' && (
          <button 
            onClick={requestPermission}
            className="px-4 py-2 bg-indigo-600 text-white text-xs font-bold rounded-xl hover:bg-indigo-700 transition-all shadow-sm"
          >
            تفعيل الآن
          </button>
        )}
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4">
        <div className="bg-white p-3 sm:p-4 rounded-2xl sm:rounded-3xl border border-gray-100 shadow-sm border-b-4 border-b-green-500">
          <p className="text-gray-500 text-[8px] sm:text-[9px] font-bold uppercase mb-1">المنجزة</p>
          <p className="text-xl sm:text-2xl font-black text-green-600">{completed.length}</p>
        </div>
        <div className="bg-white p-3 sm:p-4 rounded-2xl sm:rounded-3xl border border-gray-100 shadow-sm border-b-4 border-b-indigo-500">
          <p className="text-gray-500 text-[8px] sm:text-[9px] font-bold uppercase mb-1">قيد التنفيذ</p>
          <p className="text-xl sm:text-2xl font-black text-indigo-600">{inProgress.length}</p>
        </div>
        <div className="bg-white p-3 sm:p-4 rounded-2xl sm:rounded-3xl border border-gray-100 shadow-sm border-b-4 border-b-red-500">
          <p className="text-gray-500 text-[8px] sm:text-[9px] font-bold uppercase mb-1">متأخرة</p>
          <p className="text-xl sm:text-2xl font-black text-red-600">{overdue.length}</p>
        </div>
        <div className="bg-white p-3 sm:p-4 rounded-2xl sm:rounded-3xl border border-gray-100 shadow-sm border-b-4 border-b-orange-500">
          <p className="text-gray-500 text-[8px] sm:text-[9px] font-bold uppercase mb-1">غير منجزة</p>
          <p className="text-xl sm:text-2xl font-black text-orange-600">{uncompleted.length}</p>
        </div>
        <div className="bg-white p-3 sm:p-4 rounded-2xl sm:rounded-3xl border border-gray-100 shadow-sm border-b-4 border-b-emerald-500">
          <p className="text-gray-500 text-[8px] sm:text-[9px] font-bold uppercase mb-1">نسبة الإنجاز</p>
          <p className="text-xl sm:text-2xl font-black text-emerald-600">{successRate.toFixed(0)}%</p>
        </div>
        <div className="bg-white p-3 sm:p-4 rounded-2xl sm:rounded-3xl border border-gray-100 shadow-sm border-b-4 border-b-rose-500">
          <p className="text-gray-500 text-[8px] sm:text-[9px] font-bold uppercase mb-1">نسبة التقصير</p>
          <p className="text-xl sm:text-2xl font-black text-rose-600">{nonCompletionRate.toFixed(0)}%</p>
        </div>
      </div>

      <div className="bg-white p-4 sm:p-8 rounded-3xl border border-gray-100 shadow-sm">
        <h3 className="text-lg sm:text-xl font-bold mb-6 flex items-center gap-2">
          <Clock className="text-indigo-600" /> قائمة مهامي الشخصية
        </h3>
        
        <div className="space-y-4">
          {tasks.length === 0 ? (
            <p className="text-center py-12 text-gray-400 italic">لا توجد مهام مسندة إليك حالياً</p>
          ) : (
            tasks.sort((a, b) => new Date(b.createdAt || b.startTime).getTime() - new Date(a.createdAt || a.startTime).getTime()).map(task => {
              const status = getDetailedStatus(task);
              const taskOverdue = status === 'overdue' || status === 'uncompleted';
              const isReview = task.status === 'review';
              const isCompleted = task.status === 'completed';

              return (
                <motion.div 
                  key={task.id}
                  className={`p-4 rounded-2xl border flex flex-col sm:flex-row sm:items-center justify-between gap-4 group transition-all ${
                    isCompleted ? 'bg-gray-50 opacity-75' : 
                    isReview ? 'bg-indigo-50 border-indigo-100' :
                    taskOverdue ? 'bg-red-50 border-red-100' : 'bg-white hover:border-indigo-200'
                  }`}
                >
                  <div className="flex-1 min-w-0">
                    <p className={`font-bold text-sm sm:text-base transition-all ${isCompleted ? 'line-through text-gray-400' : 'text-gray-900 group-hover:text-indigo-600'}`}>
                      {task.title}
                    </p>
                    <div className="flex flex-wrap items-center gap-2 sm:gap-3 mt-1.5 text-[10px]">
                      <span className={`px-2 py-0.5 rounded-full font-bold shadow-sm ${
                        isCompleted ? 'bg-green-600 text-white' : 
                        isReview ? 'bg-amber-500 text-white' :
                        taskOverdue ? 'bg-red-600 text-white' : 'bg-indigo-600 text-white'
                      }`}>
                        {isCompleted ? 'منجز ومعتمد' : isReview ? 'قيد المراجعة' : taskOverdue ? 'متأخر' : 'قيد التنفيذ'}
                      </span>
                      {task.confirmedBy && (
                        <span className="text-emerald-600 font-bold bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-100 flex items-center gap-1">
                          <CheckCircle2 size={10} />
                          معتمد: {task.confirmedBy}
                        </span>
                      )}
                      <span className="text-gray-400">
                        {new Date(task.startTime).toLocaleString('ar-EG', { dateStyle: 'short', timeStyle: 'short' })}
                      </span>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    {taskOverdue && !isReview && !isCompleted && (
                      <button
                        onClick={() => handleRequestExtension(task.title, task.id)}
                        disabled={requestingId === task.id}
                        className="flex-1 sm:flex-none flex items-center justify-center gap-1.5 px-3 py-2 sm:py-1.5 bg-orange-100 text-orange-700 rounded-lg hover:bg-orange-200 transition-all text-[10px] font-bold disabled:opacity-50"
                      >
                        <CalendarClock size={14} />
                        {requestingId === task.id ? 'إرسال...' : 'طلب تمديد'}
                      </button>
                    )}
                    
                    {!isCompleted && !isReview && (
                      <button
                        onClick={() => handleFinishTask(task)}
                        disabled={finishingId === task.id}
                        className="flex-1 sm:flex-none flex items-center justify-center gap-1.5 px-4 py-2 bg-green-600 text-white rounded-xl hover:bg-green-700 transition-all font-bold text-xs shadow-sm shadow-green-100 disabled:opacity-50"
                      >
                        <CheckCircle2 size={16} />
                        {finishingId === task.id ? 'إرسال...' : 'إنجاز المهمة'}
                      </button>
                    )}
                    
                    {isReview && (
                      <span className="w-full sm:w-auto text-[10px] text-center text-amber-600 font-bold bg-amber-50 px-3 py-1.5 rounded-lg border border-amber-100">
                        بانتظار الاعتماد
                      </span>
                    )}
                  </div>
                </motion.div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};
