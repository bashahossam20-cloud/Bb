import React from 'react';
import { db } from '../lib/firebase';
import { collection, query, where, getDocs, updateDoc, doc } from 'firebase/firestore';
import { AppUser } from '../types';
import { LogIn, LogOut, User, Lock, UserCircle } from 'lucide-react';

interface AuthProps {
  onLogin: (user: AppUser) => void;
  onLogout: () => void;
  currentUser: AppUser | null;
}

export const AuthStatus: React.FC<AuthProps> = ({ onLogin, onLogout, currentUser }) => {
  const [isLoginModalOpen, setIsLoginModalOpen] = React.useState(false);
  const [username, setUsername] = React.useState('');
  const [password, setPassword] = React.useState('');
  const [error, setError] = React.useState('');
  const [loading, setLoading] = React.useState(false);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      // 1. Check master admin (hardcoded as fallback)
      if (username === 'admin' && password === 'admin123') {
        onLogin({ username: 'admin', role: 'admin' });
        setIsLoginModalOpen(false);
        setLoading(false);
        return;
      }

      // 2. Check dynamic users from Firestore
      const q = query(collection(db, 'users'), where('username', '==', username), where('password', '==', password));
      const querySnapshot = await getDocs(q);

      if (!querySnapshot.empty) {
        const userDoc = querySnapshot.docs[0];
        const userData = userDoc.data();
        
        // Update presence on login
        await updateDoc(doc(db, 'users', userDoc.id), {
          isOnline: true,
          lastSeen: new Date().toISOString()
        });

        onLogin({ 
          id: userDoc.id,
          username: userData.username, 
          role: userData.role as any 
        });
        setIsLoginModalOpen(false);
      } else {
        setError('اسم المستخدم أو كلمة المرور غير صحيحة');
      }
    } catch (err) {
      console.error(err);
      setError('حدث خطأ أثناء الاتصال بالنظام');
    } finally {
      setLoading(false);
    }
  };

  if (currentUser) {
    return (
      <div className="flex items-center gap-4 bg-white p-2 px-4 rounded-full shadow-sm border border-gray-100">
        <div className="flex items-center gap-2">
          <div className={`w-8 h-8 rounded-full flex items-center justify-center text-white ${currentUser.role === 'admin' ? 'bg-red-500' : 'bg-indigo-500'}`}>
            <UserCircle size={20} />
          </div>
          <div className="hidden sm:block">
            <p className="text-xs font-semibold">{currentUser.username}</p>
            <p className="text-[10px] text-gray-500">
              {currentUser.role === 'admin' ? 'مدير النظام' : currentUser.role === 'editor' ? 'محرر' : 'عامل'}
            </p>
          </div>
        </div>
        <button 
          onClick={onLogout}
          className="flex items-center gap-2 p-2 px-3 hover:bg-red-50 text-red-500 rounded-xl transition-all border border-transparent hover:border-red-100 font-bold text-xs"
        >
          <LogOut size={16} />
          <span className="hidden sm:inline">خروج</span>
        </button>
      </div>
    );
  }

  return (
    <>
      <button
        onClick={() => setIsLoginModalOpen(true)}
        className="flex items-center gap-2 bg-indigo-600 text-white px-6 py-2 rounded-full hover:bg-indigo-700 transition-all shadow-md hover:shadow-lg font-medium"
      >
        <LogIn size={18} />
        <span>دخول النظام</span>
      </button>

      {isLoginModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm">
          <div className="bg-white w-full max-w-md rounded-3xl shadow-2xl p-8">
            <div className="text-center mb-8">
              <div className="w-16 h-16 bg-indigo-50 text-indigo-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <Lock size={32} />
              </div>
              <h2 className="text-2xl font-bold">دخول النظام المحلي</h2>
              <p className="text-gray-500 text-sm mt-2">استخدم اسم المستخدم الخاص بك (لا يتطلب حساب جوجل)</p>
            </div>

            <form onSubmit={handleLogin} className="space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-semibold text-gray-700">اسم المستخدم</label>
                <input 
                  type="text" 
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-indigo-500 outline-none"
                  placeholder="أدخل اسم المستخدم..."
                  required
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-semibold text-gray-700">كلمة المرور</label>
                <input 
                  type="password" 
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-indigo-500 outline-none"
                  placeholder="أدخل كلمة المرور..."
                  required
                />
              </div>

              {error && <p className="text-red-500 text-xs font-medium text-center">{error}</p>}

              <div className="pt-4 flex gap-3">
                <button 
                  type="submit"
                  className="flex-1 bg-indigo-600 text-white py-3 rounded-xl hover:bg-indigo-700 font-bold shadow-lg transition-all"
                >
                  تسجيل الدخول
                </button>
                <button 
                  type="button"
                  onClick={() => setIsLoginModalOpen(false)}
                  className="px-6 py-3 border border-gray-100 bg-gray-50 rounded-xl text-gray-600 hover:bg-gray-100 font-medium transition-all"
                >
                  إلغاء
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </>
  );
};
