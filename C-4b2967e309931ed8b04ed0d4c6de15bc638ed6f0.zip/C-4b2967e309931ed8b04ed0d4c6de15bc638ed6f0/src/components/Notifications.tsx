import React from 'react';
import { Worker } from '../types';
import { Bell, AlertCircle, CheckCircle2, X } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface NotificationsProps {
  workers: Worker[];
  onViewAll?: () => void;
  onCountChange?: (count: number) => void;
}

export const NotificationSystem: React.FC<NotificationsProps> = ({ workers, onViewAll, onCountChange }) => {
  const [isOpen, setIsOpen] = React.useState(false);

  const notifications = React.useMemo(() => {
    const alerts: { id: string; workerName: string; msg: string; type: 'urgent' | 'info' }[] = [];
    const now = new Date();
    
    workers.forEach(w => {
      const tasks = w.tasks || [];
      const uncompleted = tasks.filter(t => {
        if (t.status === 'completed' || t.status === 'review') return false;
        const diff = (now.getTime() - new Date(t.startTime).getTime()) / (1000 * 60 * 60);
        return diff >= 24;
      });

      const overdue = tasks.filter(t => {
        if (t.status === 'completed' || t.status === 'review') return false;
        const diff = (now.getTime() - new Date(t.startTime).getTime()) / (1000 * 60 * 60);
        return diff >= 5 && diff < 24;
      });

      const reviewTasks = tasks.filter(t => t.status === 'review');
      
      if (uncompleted.length > 0) {
        alerts.push({
          id: `uncompleted-${w.id}`,
          workerName: w.name,
          msg: `لديه ${uncompleted.length} مهام غير منجزة تجاوزت 24 ساعة.`,
          type: 'urgent'
        });
      }

      if (reviewTasks.length > 0) {
        alerts.push({
          id: `review-${w.id}`,
          workerName: w.name,
          msg: `لديه ${reviewTasks.length} مهام جديدة بانتظار المراجعة والاعتماد.`,
          type: 'urgent'
        });
      }

      if (overdue.length > 0) {
        alerts.push({
          id: `overdue-${w.id}`,
          workerName: w.name,
          msg: `لديه ${overdue.length} مهام متأخرة (بين 5 و 24 ساعة).`,
          type: 'info'
        });
      }
    });

    return alerts;
  }, [workers]);

  React.useEffect(() => {
    onCountChange?.(notifications.length);
  }, [notifications.length, onCountChange]);

  return (
    <>
      {/* Icon with Pulsing Badge */}
      <button 
        onClick={() => setIsOpen(true)}
        className="relative p-3 bg-white hover:bg-gray-50 rounded-2xl transition-all text-gray-600 border border-gray-100 shadow-sm hover:shadow-md focus:ring-2 focus:ring-indigo-500 outline-none group"
      >
        <Bell size={24} className="group-hover:rotate-12 transition-transform" />
        {notifications.length > 0 && (
          <span className="absolute -top-1 -right-1 flex h-5 w-5">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-5 w-5 bg-red-600 text-[10px] items-center justify-center text-white font-black">
              {notifications.length}
            </span>
          </span>
        )}
      </button>

      {/* Side Panel Overlay */}
      <AnimatePresence>
        {isOpen && (
          <>
            {/* Backdrop */}
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsOpen(false)}
              className="fixed inset-0 bg-black/20 backdrop-blur-sm z-[100]"
            />

            {/* Panel */}
            <motion.div 
              initial={{ x: '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: '-100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="fixed left-0 top-0 bottom-0 w-full max-w-sm bg-white z-[101] shadow-2xl flex flex-col"
              dir="rtl"
            >
              <div className="p-6 border-b border-gray-100 flex justify-between items-center bg-gray-50/50">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-indigo-600 text-white rounded-xl flex items-center justify-center shadow-lg shadow-indigo-100">
                    <Bell size={20} />
                  </div>
                  <div>
                    <h3 className="font-black text-gray-900">مركز الإشعارات</h3>
                    <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest">التنبيهات الذكية للنظام</p>
                  </div>
                </div>
                <button 
                  onClick={() => setIsOpen(false)}
                  className="p-2 hover:bg-gray-200 rounded-xl transition-all text-gray-400"
                >
                  <X size={20} />
                </button>
              </div>
              
              <div className="flex-1 overflow-y-auto p-4 space-y-4">
                {notifications.length === 0 ? (
                  <div className="h-full flex flex-col items-center justify-center text-center p-8 space-y-4">
                    <div className="w-20 h-20 bg-gray-50 rounded-full flex items-center justify-center text-gray-200">
                      <CheckCircle2 size={48} />
                    </div>
                    <p className="text-gray-400 font-black text-sm leading-relaxed">
                      لا توجد تنبيهات حالياً.<br />النظام يعمل بكفاءة تامة!
                    </p>
                  </div>
                ) : (
                  notifications.map(notif => (
                    <motion.div 
                      key={notif.id} 
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      className={`p-5 rounded-3xl border transition-all ${
                        notif.type === 'urgent' 
                          ? 'bg-rose-50/50 border-rose-100 shadow-sm shadow-rose-50' 
                          : 'bg-white border-gray-100 shadow-sm hover:shadow-md'
                      }`}
                    >
                      <div className="flex gap-4">
                        <div className={`mt-1 h-10 w-10 shrink-0 rounded-2xl flex items-center justify-center ${
                          notif.type === 'urgent' ? 'bg-rose-600 text-white shadow-lg shadow-rose-200' : 'bg-blue-50 text-blue-600'
                        }`}>
                          {notif.type === 'urgent' ? <AlertCircle size={20} /> : <CheckCircle2 size={20} />}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex justify-between items-start mb-1">
                            <p className="text-sm font-black text-gray-900 truncate">{notif.workerName}</p>
                            {notif.type === 'urgent' && (
                              <span className="px-2 py-0.5 bg-rose-600 text-white text-[8px] font-black rounded-md animate-pulse">عاجل</span>
                            )}
                          </div>
                          <p className="text-xs text-gray-600 font-bold leading-relaxed">{notif.msg}</p>
                        </div>
                      </div>
                    </motion.div>
                  ))
                )}
              </div>

              <div className="p-6 border-t border-gray-100 bg-gray-50/50">
                <button 
                  onClick={() => {
                    setIsOpen(false);
                    onViewAll?.();
                  }}
                  className="w-full py-4 bg-indigo-600 text-white rounded-2xl font-black text-sm hover:bg-indigo-700 transition-all shadow-xl shadow-indigo-100 flex items-center justify-center gap-2 group"
                >
                  <span>عرض السجل الكامل</span>
                  <X size={16} className="rotate-45 group-hover:translate-x-1 transition-transform" />
                </button>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
};

export const NotificationsFullView: React.FC<{ workers: Worker[] }> = ({ workers }) => {
  const notifications = React.useMemo(() => {
    const alerts: { id: string; workerName: string; msg: string; type: 'urgent' | 'info'; date?: string }[] = [];
    const now = new Date();
    
    workers.forEach(w => {
      const tasks = w.tasks || [];
      const uncompleted = tasks.filter(t => {
        if (t.status === 'completed' || t.status === 'review') return false;
        const diff = (now.getTime() - new Date(t.startTime).getTime()) / (1000 * 60 * 60);
        return diff >= 24;
      });

      const overdue = tasks.filter(t => {
        if (t.status === 'completed' || t.status === 'review') return false;
        const diff = (now.getTime() - new Date(t.startTime).getTime()) / (1000 * 60 * 60);
        return diff >= 5 && diff < 24;
      });

      const reviewTasks = tasks.filter(t => t.status === 'review');
      
      if (uncompleted.length > 0) {
        alerts.push({
          id: `uncompleted-${w.id}`,
          workerName: w.name,
          msg: `لديه ${uncompleted.length} مهام غير منجزة تجاوزت 24 ساعة.`,
          type: 'urgent'
        });
      }

      if (overdue.length > 0) {
        alerts.push({
          id: `overdue-${w.id}`,
          workerName: w.name,
          msg: `لديه ${overdue.length} مهام متأخرة (بين 5 و 24 ساعة).`,
          type: 'info'
        });
      }

      if (reviewTasks.length > 0) {
        alerts.push({
          id: `review-${w.id}`,
          workerName: w.name,
          msg: `لديه ${reviewTasks.length} مهام بانتظار المراجعة والاعتماد.`,
          type: 'info'
        });
      }
    });

    return alerts;
  }, [workers]);

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-black text-gray-900">مركز التنبيهات والإشعارات</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {notifications.length === 0 ? (
          <div className="col-span-full py-20 text-center bg-white rounded-3xl border border-dashed border-gray-200 text-gray-400 font-bold">
            لا توجد تنبيهات حالياً. النظام مستقر وجميع الأعمال قيد التنفيذ بشكل سليم.
          </div>
        ) : (
          notifications.map(notif => (
            <div 
              key={notif.id} 
              className={`p-6 rounded-[2rem] border transition-all hover:shadow-lg ${
                notif.type === 'urgent' ? 'bg-white border-red-100 shadow-red-50' : 'bg-white border-blue-100 shadow-blue-50'
              }`}
            >
              <div className="flex gap-5 items-start">
                <div className={`p-4 rounded-2xl ${notif.type === 'urgent' ? 'bg-red-50 text-red-500' : 'bg-blue-50 text-blue-500'}`}>
                  {notif.type === 'urgent' ? <AlertCircle size={32} /> : <Bell size={32} />}
                </div>
                <div className="flex-1">
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-sm font-black text-gray-900">{notif.workerName}</span>
                    <span className={`text-[10px] font-black uppercase px-2 py-1 rounded-lg ${
                      notif.type === 'urgent' ? 'bg-red-50 text-red-600' : 'bg-blue-50 text-blue-600'
                    }`}>
                      {notif.type === 'urgent' ? 'عاجل جداً' : 'تنبيه إداري'}
                    </span>
                  </div>
                  <p className="text-gray-600 font-medium leading-relaxed">{notif.msg}</p>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
