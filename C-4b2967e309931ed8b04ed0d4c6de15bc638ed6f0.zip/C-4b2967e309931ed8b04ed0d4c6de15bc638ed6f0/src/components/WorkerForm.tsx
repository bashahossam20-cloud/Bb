import React from 'react';
import { Worker, Task, AppUser } from '../types';
import { X, CheckCircle2, Circle, Plus, Trash2 } from 'lucide-react';
import { collection, addDoc, updateDoc, doc, serverTimestamp, getDocs, query } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { motion, AnimatePresence } from 'motion/react';

interface WorkerFormProps {
  isOpen: boolean;
  onClose: () => void;
  initialData: Worker | null;
  currentUser: AppUser;
  existingWorkers: Worker[];
}

export const WorkerForm: React.FC<WorkerFormProps> = ({ isOpen, onClose, initialData, currentUser, existingWorkers }) => {
  const [formData, setFormData] = React.useState({
    name: '',
    role: '',
    phone: '',
    password: '123' // Default password for new workers
  });
  const [tasks, setTasks] = React.useState<Task[]>([]);
  
  const [newTaskTitle, setNewTaskTitle] = React.useState('');

  React.useEffect(() => {
    const fetchUserPassword = async () => {
      if (initialData) {
        const usersSnapshot = await getDocs(query(collection(db, 'users')));
        const userDoc = usersSnapshot.docs.find(d => 
          d.data().username.trim().toLowerCase() === initialData.name.trim().toLowerCase()
        );
        if (userDoc) {
          setFormData(prev => ({ ...prev, password: userDoc.data().password }));
        }
      }
    };

    if (initialData) {
      setFormData({
        name: initialData.name,
        role: initialData.role,
        phone: initialData.phone || '',
        password: formData.password
      });
      setTasks(initialData.tasks || []);
      fetchUserPassword();
    } else {
      setFormData({ name: '', role: '', phone: '', password: '123' });
      setTasks([]);
    }
  }, [initialData, isOpen]);

  const addTask = () => {
    if (!newTaskTitle.trim()) return;
    const now = new Date().toISOString();
    const newTask: Task = {
      id: Math.random().toString(36).substr(2, 9),
      title: newTaskTitle,
      startTime: now,
      endTime: now,
      status: 'pending',
      createdAt: now,
      createdBy: currentUser.username
    };
    setTasks(prev => [...prev, newTask]);
    setNewTaskTitle('');
  };

  const toggleTaskStatus = (taskId: string) => {
    setTasks(prev => prev.map(t => 
      t.id === taskId ? { ...t, status: t.status === 'completed' ? 'pending' : 'completed' } : t
    ));
  };

  const removeTask = (taskId: string) => {
    setTasks(prev => prev.filter(t => t.id !== taskId));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.role) return;

    // Duplicate name check
    const cleanName = formData.name.trim();
    const nameExists = existingWorkers.some(w => 
      w.name.trim() === cleanName && (!initialData || w.id !== initialData.id)
    );

    if (nameExists) {
      alert(`عذراً، هذا الاسم (${cleanName}) مسجل مسبقاً في النظام. لا يمكن تكرار أسماء العاملين.`);
      return;
    }

    try {
      const cleanName = formData.name.trim();
      const data = {
        name: cleanName,
        role: formData.role,
        phone: formData.phone,
        tasks,
        updatedAt: serverTimestamp(),
      };

      if (initialData) {
        // Update Worker
        await updateDoc(doc(db, 'workers', initialData.id), data);
        
        // Sync with User account
        const usersSnapshot = await getDocs(query(collection(db, 'users')));
        const userDoc = usersSnapshot.docs.find(d => 
          d.data().username.trim().toLowerCase() === initialData.name.trim().toLowerCase()
        );
        if (userDoc) {
          await updateDoc(doc(db, 'users', userDoc.id), {
            username: cleanName,
            password: formData.password,
            updatedAt: serverTimestamp()
          });
        }
      } else {
        // Create Worker
        await addDoc(collection(db, 'workers'), {
          ...data,
          createdAt: serverTimestamp(),
        });

        // Create User account
        await addDoc(collection(db, 'users'), {
          username: cleanName,
          password: formData.password,
          role: 'worker',
          createdAt: new Date().toISOString()
        });
      }
      onClose();
    } catch (error) {
      handleFirestoreError(error, initialData ? OperationType.UPDATE : OperationType.CREATE, initialData ? `workers/${initialData.id}` : 'workers');
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-0 sm:p-4 bg-black/40 backdrop-blur-sm">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: 20 }}
        className="bg-white w-full sm:max-w-2xl sm:rounded-3xl shadow-2xl overflow-hidden flex flex-col h-full sm:h-auto sm:max-h-[90vh]"
      >
        <div className="p-5 sm:p-6 border-b border-gray-100 flex justify-between items-center bg-gray-50/50">
          <h2 className="text-lg sm:text-xl font-black">{initialData ? 'تعديل بيانات العامل' : 'إضافة عامل جديد'}</h2>
          <button onClick={onClose} className="p-2 hover:bg-gray-200 rounded-full transition-colors">
            <X size={20} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="flex flex-col flex-1 overflow-hidden">
          <div className="p-5 sm:p-6 overflow-y-auto space-y-6 flex-1 pb-20 sm:pb-6">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-xs font-bold text-gray-400 uppercase tracking-widest pl-1">الاسم الكامل</label>
                <input 
                  type="text" 
                  value={formData.name} 
                  onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                  required
                  className="w-full px-4 py-3 rounded-xl border border-gray-100 bg-gray-50/50 focus:bg-white focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none transition-all text-sm font-medium"
                  placeholder="أدخل الاسم..."
                />
              </div>
              <div className="space-y-2">
                <label className="text-xs font-bold text-gray-400 uppercase tracking-widest pl-1">الصفة الوظيفية</label>
                <input 
                  type="text" 
                  value={formData.role} 
                  onChange={(e) => setFormData(prev => ({ ...prev, role: e.target.value }))}
                  required
                  className="w-full px-4 py-3 rounded-xl border border-gray-100 bg-gray-50/50 focus:bg-white focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none transition-all text-sm font-medium"
                  placeholder="مثال: محرر صحفي"
                />
              </div>
              <div className="space-y-2">
                <label className="text-xs font-bold text-gray-400 uppercase tracking-widest pl-1">رقم الهاتف</label>
                <input 
                  type="tel" 
                  value={formData.phone} 
                  onChange={(e) => setFormData(prev => ({ ...prev, phone: e.target.value }))}
                  required
                  className="w-full px-4 py-3 rounded-xl border border-gray-100 bg-gray-50/50 focus:bg-white focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none transition-all text-sm font-medium text-left"
                  dir="ltr"
                  placeholder="+966 5x xxx xxxx"
                />
              </div>
              <div className="space-y-2">
                <label className="text-xs font-bold text-gray-400 uppercase tracking-widest pl-1">كلمة المرور</label>
                <input 
                  type="text" 
                  value={formData.password} 
                  onChange={(e) => setFormData(prev => ({ ...prev, password: e.target.value }))}
                  required
                  className="w-full px-4 py-3 rounded-xl border border-gray-100 bg-gray-50/50 focus:bg-white focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none transition-all text-sm font-medium text-left"
                  dir="ltr"
                  placeholder="Password..."
                />
              </div>
            </div>

            <div className="pt-4 border-t border-gray-50 space-y-4">
              <h3 className="text-xs font-black text-gray-900 uppercase tracking-widest">إدارة المهام</h3>
              
              <div className="bg-indigo-50/50 p-4 rounded-2xl border border-indigo-100/50 flex gap-2">
                <input 
                  type="text" 
                  value={newTaskTitle}
                  onChange={(e) => setNewTaskTitle(e.target.value)}
                  className="flex-1 px-4 py-3 rounded-xl border border-gray-100 focus:ring-2 focus:ring-indigo-500 outline-none text-sm font-medium bg-white"
                  placeholder="وصف المهمة الجديدة..."
                  onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), addTask())}
                />
                <button 
                  type="button" 
                  onClick={addTask}
                  className="h-[46px] px-6 bg-indigo-600 text-white font-black rounded-xl hover:bg-indigo-700 transition-all shadow-md active:scale-95 flex items-center justify-center gap-2"
                >
                  <Plus size={20} />
                  <span>إضافة</span>
                </button>
              </div>

              <div className="space-y-3">
                <h4 className="text-[10px] font-black text-gray-400 uppercase tracking-widest">جميع مهام العامل ({tasks.length})</h4>
                <div className="space-y-2">
                  <AnimatePresence initial={false}>
                    {tasks.sort((a, b) => new Date(b.createdAt || b.startTime).getTime() - new Date(a.createdAt || a.startTime).getTime()).map((task) => (
                      <motion.div 
                        key={task.id}
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, scale: 0.95 }}
                        className={`flex flex-col p-4 rounded-2xl border gap-3 ${
                          task.status === 'completed' ? 'bg-green-50/50 border-green-100' : 'bg-gray-50 border-gray-100'
                        }`}
                      >
                        <div className="flex justify-between items-start gap-3">
                          <p className={`font-bold text-sm flex-1 ${task.status === 'completed' ? 'line-through text-gray-400' : 'text-gray-800'}`}>
                            {task.title}
                          </p>
                          <div className="flex items-center gap-1">
                            <button 
                              type="button" 
                              onClick={() => toggleTaskStatus(task.id)}
                              className={`p-2 rounded-lg transition-all ${
                                task.status === 'completed' ? 'text-green-600 bg-white shadow-sm' : 'text-gray-400 hover:bg-gray-200'
                              }`}
                            >
                              <CheckCircle2 size={20} />
                            </button>
                            <button 
                              type="button" 
                              onClick={() => removeTask(task.id)}
                              className="p-2 text-red-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-all"
                            >
                              <Trash2 size={20} />
                            </button>
                          </div>
                        </div>
                        <div className="flex items-center gap-3 text-[9px] font-bold text-gray-400 border-t border-gray-100/50 pt-2">
                          <span className="flex items-center gap-1">📅 أنشئت في: {new Date(task.createdAt || task.startTime).toLocaleString('ar-EG')}</span>
                          <span className="text-gray-300">|</span>
                          <span className="text-indigo-400">بواسطة: {task.createdBy}</span>
                        </div>
                      </motion.div>
                    ))}
                  </AnimatePresence>
                  {tasks.length === 0 && (
                    <p className="text-center py-10 text-gray-400 text-xs italic border-2 border-dashed border-gray-100 rounded-2xl">لا توجد مهام مسجلة حالياً</p>
                  )}
                </div>
              </div>
            </div>
          </div>

          <div className="p-5 sm:p-6 border-t border-gray-100 sticky sm:static bottom-0 left-0 right-0 bg-white sm:bg-transparent z-10 flex gap-3">
            <button
              type="submit"
              className="flex-1 bg-indigo-600 text-white py-4 rounded-2xl hover:bg-indigo-700 transition-all shadow-xl font-black text-sm active:scale-95"
            >
              {initialData ? 'تحديث المعلومات' : 'حفظ البيانات'}
            </button>
            <button
              type="button"
              onClick={onClose}
              className="px-6 py-4 border border-gray-100 bg-gray-50 rounded-2xl hover:bg-gray-100 transition-all text-gray-600 font-bold text-sm"
            >
              إلغاء
            </button>
          </div>
        </form>
      </motion.div>
    </div>
  );
};
