import React from 'react';
import { Worker } from '../types';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';

interface StatsProps {
  workers: Worker[];
  onFilterClick: (type: 'completed' | 'overdue' | 'uncompleted' | 'in-progress' | 'all-workers', label: string) => void;
}

export const StatsSummary: React.FC<StatsProps> = ({ workers, onFilterClick }) => {
  const stats = React.useMemo(() => {
    const totalWorkers = workers.length;
    let totalCompleted = 0;
    let totalOverdue = 0;
    let totalInProgress = 0;
    let totalUncompleted = 0;
    let totalReview = 0;
    const now = new Date();

    workers.forEach(w => {
      (w.tasks || []).forEach(t => {
        const startTime = new Date(t.startTime).getTime();
        const diffHours = (now.getTime() - startTime) / (1000 * 60 * 60);

        if (t.status === 'review') {
          totalReview++;
        } else if (t.status === 'completed') {
          totalCompleted++;
        } else {
          if (diffHours >= 24) totalUncompleted++;
          else if (diffHours >= 5) totalOverdue++;
          else totalInProgress++;
        }
      });
    });

    const totalTasks = totalCompleted + totalUncompleted + totalOverdue + totalInProgress + totalReview;
    const completionRate = totalTasks > 0 ? (totalCompleted / totalTasks) * 100 : 0;

    const chartData = workers.map(w => {
      const wTasks = w.tasks || [];
      return {
        name: w.name,
        منجزة: wTasks.filter(t => t.status === 'completed').length,
        مراجعة: wTasks.filter(t => t.status === 'review').length,
        متأخرة: wTasks.filter(t => {
          if (t.status === 'completed' || t.status === 'review') return false;
          const diff = (now.getTime() - new Date(t.startTime).getTime()) / (1000 * 60 * 60);
          return diff >= 5 && diff < 24;
        }).length,
        قائمة: wTasks.filter(t => {
          if (t.status === 'completed' || t.status === 'review') return false;
          const diff = (now.getTime() - new Date(t.startTime).getTime()) / (1000 * 60 * 60);
          return diff < 5;
        }).length,
      };
    });

    const pieData = [
      { name: 'منجزة', value: totalCompleted },
      { name: 'بانتظار الاعتماد', value: totalReview },
      { name: 'متأخرة', value: totalOverdue },
      { name: 'غير منجزة', value: totalUncompleted },
      { name: 'قيد التنفيذ', value: totalInProgress }
    ];

    return { 
      totalWorkers, 
      totalCompleted, 
      totalOverdue, 
      totalInProgress, 
      totalUncompleted, 
      totalReview,
      totalTasks,
      completionRate, 
      chartData, 
      pieData 
    };
  }, [workers]);

  const COLORS = ['#10b981', '#f59e0b', '#ef4444', '#f97316', '#6366f1'];

  return (
    <div className="space-y-8">
      {/* Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-4 xl:grid-cols-7 gap-3">
        <StatCard 
          label="إجمالي العاملين" 
          value={stats.totalWorkers} 
          color="indigo" 
          onClick={() => onFilterClick('all-workers', 'إجمالي العاملين')}
        />
        <StatCard 
          label="منجز ومعتمد" 
          value={stats.totalCompleted} 
          color="emerald" 
          onClick={() => onFilterClick('completed', 'المهام المنجزة والمعتمدة')}
        />
        <StatCard 
          label="بانتظار الاعتماد" 
          value={stats.totalReview} 
          color="amber" 
          onClick={() => onFilterClick('review', 'مهام بانتظار الاعتماد')}
        />
        <StatCard 
          label="المهام المتأخرة" 
          value={stats.totalOverdue} 
          color="red" 
          onClick={() => onFilterClick('overdue', 'المهام المتأخرة')}
        />
        <StatCard 
          label="المهام غير المنجزة" 
          value={stats.totalUncompleted} 
          color="orange" 
          onClick={() => onFilterClick('uncompleted', 'المهام غير المنجزة')}
        />
        <StatCard 
          label="المهام قيد التنفيذ" 
          value={stats.totalInProgress} 
          color="blue" 
          onClick={() => onFilterClick('in-progress', 'المهام قيد التنفيذ')}
        />
        <StatCard 
          label="إجمالي المهام" 
          value={stats.totalTasks} 
          color="indigo" 
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Bar Chart */}
        <div className="bg-white p-6 rounded-3xl shadow-sm border border-gray-100">
          <h3 className="text-lg font-bold mb-6">مقارنة المهام لكل عامل</h3>
          <div className="h-80 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={stats.chartData} layout="vertical" margin={{ left: 20 }}>
                <CartesianGrid strokeDasharray="3 3" horizontal={false} opacity={0.1} />
                <XAxis type="number" hide />
                <YAxis dataKey="name" type="category" width={80} style={{ fontSize: '12px' }} />
                <Tooltip 
                   cursor={{ fill: '#f9fafb' }}
                   contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }}
                />
                <Bar dataKey="منجزة" fill="#10b981" radius={[0, 4, 4, 0]} barSize={12} />
                <Bar dataKey="مراجعة" fill="#f59e0b" radius={[0, 4, 4, 0]} barSize={12} />
                <Bar dataKey="متأخرة" fill="#ef4444" radius={[0, 4, 4, 0]} barSize={12} />
                <Bar dataKey="قائمة" fill="#6366f1" radius={[0, 4, 4, 0]} barSize={12} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Pie Chart */}
        <div className="bg-white p-6 rounded-3xl shadow-sm border border-gray-100 flex flex-col">
          <h3 className="text-lg font-bold mb-6">توزيع حالة المهام الكلي</h3>
          <div className="flex-1 min-h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={stats.pieData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={100}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {stats.pieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} stroke="none" />
                  ))}
                </Pie>
                <Tooltip contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }} />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="flex flex-wrap justify-center gap-4 text-[10px] font-medium mt-4">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-emerald-500"></div>
              <span>منجزة</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-amber-500"></div>
              <span>بانتظار الاعتماد</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-red-500"></div>
              <span>متأخرة</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const StatCard: React.FC<{ label: string; value: string | number; color: string; onClick?: () => void }> = ({ label, value, color, onClick }) => {
  const colorMap: Record<string, string> = {
    blue: 'text-blue-600',
    green: 'text-green-600',
    red: 'text-red-600',
    orange: 'text-orange-600',
    indigo: 'text-indigo-600',
    emerald: 'text-emerald-600',
    amber: 'text-amber-600',
    gray: 'text-gray-600'
  };

  const borderMap: Record<string, string> = {
    blue: 'border-b-blue-500',
    green: 'border-b-green-500',
    red: 'border-b-red-500',
    orange: 'border-b-orange-500',
    indigo: 'border-b-indigo-500',
    emerald: 'border-b-emerald-500',
    amber: 'border-b-amber-500',
    gray: 'border-b-gray-500'
  };

  return (
    <button 
      disabled={!onClick}
      onClick={onClick}
      className={`bg-white p-4 sm:p-6 rounded-3xl shadow-sm border border-gray-100 text-right transition-all flex flex-col justify-between ${
        onClick ? 'hover:shadow-lg hover:scale-[1.02] active:scale-95 cursor-pointer border-b-4' : 'border-b-2'
      } ${borderMap[color] || 'border-b-gray-100'}`}
    >
      <p className="text-gray-500 text-[9px] sm:text-xs mb-1 font-bold uppercase tracking-wider">{label}</p>
      <p className={`text-xl sm:text-3xl font-black ${colorMap[color] || 'text-gray-900'}`}>{value}</p>
      {onClick && (
        <p className="text-[8px] sm:text-[10px] text-gray-400 mt-2 font-medium hidden sm:block">استعراض التفاصيل</p>
      )}
    </button>
  );
};
