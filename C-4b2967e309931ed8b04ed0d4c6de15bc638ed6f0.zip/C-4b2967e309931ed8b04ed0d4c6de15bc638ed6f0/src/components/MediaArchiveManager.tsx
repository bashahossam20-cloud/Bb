import React from 'react';
import { collection, query, onSnapshot, addDoc, serverTimestamp, orderBy, deleteDoc, doc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { MediaArchive, Worker } from '../types';
import { Archive, Plus, Database, User, Calendar, Search, MapPin, Video, Aperture, Trash2, Undo2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface MediaArchiveManagerProps {
  workers: Worker[];
  currentUser: any;
}

export const MediaArchiveManager: React.FC<MediaArchiveManagerProps> = ({ workers, currentUser }) => {
  const [archives, setArchives] = React.useState<MediaArchive[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [showAddForm, setShowAddForm] = React.useState(false);
  const [typeFilter, setTypeFilter] = React.useState('all');
  const [searchTerm, setSearchTerm] = React.useState('');

  const [formData, setFormData] = React.useState({
    workerId: '',
    type: 'فيديو',
    specifications: '',
    location: '',
    submittedAt: new Date().toISOString().split('T')[0]
  });

  React.useEffect(() => {
    const q = query(collection(db, 'media_archives'), orderBy('createdAt', 'desc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const data = snapshot.docs.map(d => ({ id: d.id, ...d.data() } as MediaArchive));
      setArchives(data);
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  const handleAddArchive = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.workerId || !formData.type || !formData.submittedAt || !formData.location) return;

    const worker = workers.find(w => w.id === formData.workerId);
    
    try {
      await addDoc(collection(db, 'media_archives'), {
        ...formData,
        workerName: worker?.name || 'غير معروف',
        status: 'archived',
        createdAt: serverTimestamp()
      });
      setShowAddForm(false);
      setFormData({
        workerId: '',
        type: 'فيديو',
        specifications: '',
        location: '',
        submittedAt: new Date().toISOString().split('T')[0]
      });
      alert('تمت إضافة المادة إلى الأرشيف بنجاح');
    } catch (err) {
      console.error(err);
      alert('فشل في إضافة المادة للأرشيف');
    }
  };

  // Correcting delete function
  const confirmDelete = async (id: string) => {
    if (!confirm('هل أنت متأكد من حذف هذا السجل من الأرشيف نهائياً؟')) return;
    try {
      await deleteDoc(doc(db, 'media_archives', id));
    } catch (err) {
      console.error(err);
      alert('فشل في الحذف');
    }
  };

  const filteredArchives = archives.filter(a => {
    const matchesType = typeFilter === 'all' || a.type === typeFilter;
    const matchesSearch = a.workerName.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          a.specifications.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          a.location.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesType && matchesSearch;
  });

  const mediaTypes = ['فيديو', 'صور', 'مادة خام', 'مشروع مونتاج', 'أخرى'];

  if (loading) return (
    <div className="flex items-center justify-center py-20">
      <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
    </div>
  );

  return (
    <div className="space-y-8 pb-20 text-right" dir="rtl">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-white p-6 rounded-3xl border border-gray-100 shadow-sm">
        <div>
          <h2 className="text-2xl font-black text-gray-900 mb-1">أرشيف المواد الإعلامية</h2>
          <p className="text-gray-500 font-medium text-sm">توثيق وحفظ جميع المواد الصادرة عن الكادر الإعلامي.</p>
        </div>
        <button 
          onClick={() => setShowAddForm(!showAddForm)}
          className="flex items-center gap-2 px-6 py-3 bg-rose-600 text-white rounded-2xl font-bold hover:bg-rose-700 transition-all shadow-lg shadow-rose-100"
        >
          {showAddForm ? <Undo2 size={20} /> : <Plus size={20} />}
          <span>{showAddForm ? 'إلغاء' : 'إضافة مادة للأرشيف'}</span>
        </button>
      </div>

      <AnimatePresence>
        {showAddForm && (
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="bg-white p-8 rounded-[2.5rem] border border-rose-50 shadow-xl shadow-rose-50/50"
          >
            <form onSubmit={handleAddArchive} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <div className="space-y-2">
                <label className="text-xs font-black text-gray-400 uppercase tracking-widest mr-2">الموظف المسلّم</label>
                <select 
                  value={formData.workerId}
                  onChange={(e) => setFormData({...formData, workerId: e.target.value})}
                  className="w-full px-4 py-3.5 bg-gray-50 rounded-xl border border-gray-100 outline-none focus:ring-2 focus:ring-rose-500 focus:bg-white transition-all text-sm font-bold"
                  required
                >
                  <option value="">اختر الموظف...</option>
                  {workers.map(w => (
                    <option key={w.id} value={w.id}>{w.name} ({w.role})</option>
                  ))}
                </select>
              </div>

              <div className="space-y-2">
                <label className="text-xs font-black text-gray-400 uppercase tracking-widest mr-2">نوع المادة</label>
                <select 
                  value={formData.type}
                  onChange={(e) => setFormData({...formData, type: e.target.value})}
                  className="w-full px-4 py-3.5 bg-gray-50 rounded-xl border border-gray-100 outline-none focus:ring-2 focus:ring-rose-500 focus:bg-white transition-all text-sm font-bold"
                  required
                >
                  {mediaTypes.map(t => (
                    <option key={t} value={t}>{t}</option>
                  ))}
                </select>
              </div>

              <div className="space-y-2">
                <label className="text-xs font-black text-gray-400 uppercase tracking-widest mr-2">تاريخ التسليم</label>
                <input 
                  type="date"
                  value={formData.submittedAt}
                  onChange={(e) => setFormData({...formData, submittedAt: e.target.value})}
                  className="w-full px-4 py-3.5 bg-gray-50 rounded-xl border border-gray-100 outline-none focus:ring-2 focus:ring-rose-500 focus:bg-white transition-all text-sm font-bold"
                  required
                />
              </div>

              <div className="space-y-2 md:col-span-2">
                <label className="text-xs font-black text-gray-400 uppercase tracking-widest mr-2">مواصفات المادة</label>
                <input 
                  type="text"
                  placeholder="مثال: تغطية فعالية كذا - دقة 4K - 60fps..."
                  value={formData.specifications}
                  onChange={(e) => setFormData({...formData, specifications: e.target.value})}
                  className="w-full px-4 py-3.5 bg-gray-50 rounded-xl border border-gray-100 outline-none focus:ring-2 focus:ring-rose-500 focus:bg-white transition-all text-sm font-bold placeholder:text-gray-300"
                  required
                />
              </div>

              <div className="space-y-2">
                <label className="text-xs font-black text-gray-400 uppercase tracking-widest mr-2">مكان الحفظ (رابط أو قرص)</label>
                <input 
                  type="text"
                  placeholder="مثال: Google Drive / Hard Disk #4..."
                  value={formData.location}
                  onChange={(e) => setFormData({...formData, location: e.target.value})}
                  className="w-full px-4 py-3.5 bg-gray-50 rounded-xl border border-gray-100 outline-none focus:ring-2 focus:ring-rose-500 focus:bg-white transition-all text-sm font-bold placeholder:text-gray-300"
                  required
                />
              </div>

              <div className="md:col-span-3 pt-4">
                <button type="submit" className="w-full py-4 bg-rose-600 text-white rounded-2xl font-black text-lg hover:bg-rose-700 transition-all shadow-xl shadow-rose-100">
                  تأكيد الأرشفة وحفظ المادة
                </button>
              </div>
            </form>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        {/* Sidebar Filters */}
        <div className="lg:col-span-1 space-y-4">
          <div className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm space-y-6">
            <div>
              <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-3 block">بحث في الأرشيف</label>
              <div className="relative">
                <Search size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400" />
                <input 
                  type="text"
                  placeholder="ابحث عن مادة أو موظف..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pr-10 pl-4 py-3 bg-gray-50 text-xs rounded-xl border border-transparent focus:bg-white focus:border-rose-100 outline-none transition-all"
                />
              </div>
            </div>

            <div>
              <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-3 block">نوع المادة</label>
              <div className="space-y-2">
                <button 
                  onClick={() => setTypeFilter('all')}
                  className={`w-full text-right px-4 py-2.5 rounded-xl text-xs font-bold transition-all ${typeFilter === 'all' ? 'bg-rose-600 text-white shadow-md' : 'hover:bg-gray-50 text-gray-600'}`}
                >
                  الكل
                </button>
                {mediaTypes.map(t => (
                  <button 
                    key={t}
                    onClick={() => setTypeFilter(t)}
                    className={`w-full text-right px-4 py-2.5 rounded-xl text-xs font-bold transition-all ${typeFilter === t ? 'bg-rose-600 text-white shadow-md' : 'hover:bg-gray-50 text-gray-600'}`}
                  >
                    {t}
                  </button>
                ))}
              </div>
            </div>

            <div className="pt-4 border-t border-gray-50">
              <div className="bg-rose-50 p-4 rounded-2xl">
                <div className="flex items-center gap-2 text-rose-600 mb-1">
                  <Database size={16} />
                  <span className="text-xs font-black">إجمالي المواد</span>
                </div>
                <p className="text-2xl font-black text-rose-700">{archives.length}</p>
              </div>
            </div>
          </div>
        </div>

        {/* List View */}
        <div className="lg:col-span-3">
          {filteredArchives.length === 0 ? (
            <div className="bg-white p-20 rounded-[3rem] border border-dashed border-gray-200 text-center space-y-4">
              <div className="w-16 h-16 bg-gray-50 rounded-full flex items-center justify-center mx-auto text-gray-300">
                <Archive size={32} />
              </div>
              <p className="text-gray-400 font-bold">لا يوجد مواد مؤرشفة مطابقة للبحث حالياً.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {filteredArchives.map(archive => (
                <motion.div 
                  key={archive.id}
                  layout
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="bg-white p-6 rounded-[2.5rem] border border-gray-100 shadow-sm hover:shadow-xl transition-all group"
                >
                  <div className="flex justify-between items-start mb-6">
                    <div className="p-4 rounded-2xl bg-rose-50 text-rose-600 group-hover:scale-110 transition-all">
                      {archive.type === 'فيديو' ? <Video size={24} /> : <Aperture size={24} />}
                    </div>
                    <div className="flex flex-col items-end gap-2">
                       <span className="px-3 py-1 bg-gray-100 text-gray-500 rounded-lg text-[10px] font-black uppercase">مؤرشفة</span>
                       <button 
                        onClick={() => archive.id && confirmDelete(archive.id)}
                        className="p-2 text-gray-300 hover:text-red-500 hover:bg-red-50 rounded-lg transition-all"
                      >
                        <Trash2 size={14} />
                       </button>
                    </div>
                  </div>

                  <div className="space-y-4 mb-6">
                    <div>
                      <div className="flex items-center gap-2 text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">
                        <User size={12} />
                        <span>المسلّم</span>
                      </div>
                      <p className="text-lg font-black text-gray-900">{archive.workerName}</p>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <div className="flex items-center gap-2 text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">
                          <Database size={12} />
                          <span>النوع</span>
                        </div>
                        <p className="font-bold text-gray-700">{archive.type}</p>
                      </div>
                      <div>
                        <div className="flex items-center gap-2 text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">
                          <Calendar size={12} />
                          <span>تاريخ الأرشفة</span>
                        </div>
                        <p className="font-bold text-gray-700">{archive.submittedAt}</p>
                      </div>
                    </div>

                    <div>
                      <div className="flex items-center gap-2 text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">
                        <Database size={12} />
                        <span>مواصفات المادة</span>
                      </div>
                      <p className="text-sm font-bold text-gray-600 bg-gray-50 p-3 rounded-xl border border-gray-100 leading-relaxed">
                        {archive.specifications}
                      </p>
                    </div>

                    <div className="pt-4 border-t border-gray-50 flex items-center gap-3">
                      <div className="w-10 h-10 bg-indigo-50 text-indigo-600 rounded-xl flex items-center justify-center">
                        <MapPin size={18} />
                      </div>
                      <div>
                        <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-0.5">مكان الحفظ والاستلام</p>
                        <p className="text-xs font-black text-indigo-600">{archive.location}</p>
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
