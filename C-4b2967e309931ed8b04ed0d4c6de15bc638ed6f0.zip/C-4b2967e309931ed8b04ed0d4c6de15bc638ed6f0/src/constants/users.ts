export type UserRole = 'admin' | 'editor';

export interface AppUser {
  username: string;
  role: UserRole;
}

export const VALID_USERS: Record<string, { password: string; role: UserRole }> = {
  'admin': { password: 'admin123', role: 'admin' },
  'user1': { password: 'user123', role: 'editor' },
  'user2': { password: 'user123', role: 'editor' },
  'user3': { password: 'user123', role: 'editor' },
};
