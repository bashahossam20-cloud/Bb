import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore, doc, getDocFromServer, initializeFirestore } from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';

const app = initializeApp(firebaseConfig);

// Using initializeFirestore with forceLongPolling to improve connectivity on mobile/restrictive networks
export const db = initializeFirestore(app, {
  experimentalForceLongPolling: true,
  // Using the firestoreDatabaseId from config
}, firebaseConfig.firestoreDatabaseId);

export const auth = getAuth();

/**
 * Validates Firestore connection on boot
 */
async function testConnection() {
  try {
    // Try to get a specific document to test connectivity
    // This will error if the backend is unreachable
    await getDocFromServer(doc(db, 'test', 'connection'));
    console.log("Firestore connected successfully.");
  } catch (error: any) {
    console.error("Firestore connectivity test failed:", error);
    
    // Check for specific error types
    const errorMessage = error?.message || String(error);
    
    if (errorMessage.includes('the client is offline') || 
        errorMessage.includes('Backend didn\'t respond') || 
        errorMessage.includes('Could not reach')) {
      console.warn("⚠️ مشكلة في الاتصال بقاعدة البيانات. قد يكون ذلك بسبب جدار حماية أو شبكة الجوال.");
    } else {
      console.warn("⚠️ تنبيه: تعذر التحقق من الاتصال. يرجى التأكد من توفر الإنترنت.");
    }
  }
}
testConnection();

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
  }
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
    },
    operationType,
    path
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}
